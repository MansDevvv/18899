public static class Storage
{
    public static int wood;
    public static int stone;
    public static int food;        // съедобная еда (ягоды)
    public static int poisonFood;  // ядовитая еда
    public static float research;

    public static void Add(ResourceType t, int n)
    {
        if (t == ResourceType.Wood) wood += n;
        else if (t == ResourceType.Stone) stone += n;
        else food += n;
    }

    public static void Clear()
    {
        wood = 0; stone = 0; food = 0; poisonFood = 0; research = 0f;
    }
}