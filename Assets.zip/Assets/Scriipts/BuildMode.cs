using System.Collections.Generic;
using UnityEngine;
public class BuildMode : MonoBehaviour
{
public GameObject woodWallPrefab;
public GameObject stoneWallPrefab;
public GameObject bedPrefab;
public GameObject cotPrefab;
public GameObject deskPrefab;
public GameObject doorPrefab;
public enum WallType { Wood, Stone }
public enum BuildKind { Wall, Bed, Cot, Desk, Door }
public class BuildItem
{
public string name; public string category; public GameObject prefab;
public ResourceType costType; public int cost; public WallType wallType;
public BuildKind kind = BuildKind.Wall;
}
public static readonly List<BuildItem> items = new List<BuildItem>();
public static BuildItem Current { get; private set; }
public static bool IsActive { get; private set; }
public static int WoodCost = 10;
public static int StoneCost = 10;
public static readonly Dictionary<Vector2Int, GameObject> blueprints = new Dictionary<Vector2Int, GameObject>();
public static readonly Dictionary<Vector2Int, WallType> blueprintTypes = new Dictionary<Vector2Int, WallType>();
public static readonly Dictionary<Vector2Int, BuildKind> blueprintKinds = new Dictionary<Vector2Int, BuildKind>();
public static readonly HashSet<Vector2Int> designated = new HashSet<Vector2Int>();
public static readonly Dictionary<Vector2Int, int> builders = new Dictionary<Vector2Int, int>();
public static readonly Dictionary<Vector2Int, float> buildProgress = new Dictionary<Vector2Int, float>();
public static readonly Dictionary<Vector2Int, int> delivered = new Dictionary<Vector2Int, int>();
public static int BuilderCount(Vector2Int c) => builders.TryGetValue(c, out var v) ? v : 0;
public static void AddBuilder(Vector2Int c) => builders[c] = BuilderCount(c) + 1;
public static void RemoveBuilder(Vector2Int c)
{
if (builders.TryGetValue(c, out var v)) { v--; if (v <= 0) builders.Remove(c); else builders[c] = v; }
}
public static float GetProgress(Vector2Int c) => buildProgress.TryGetValue(c, out var p) ? p : 0f;
public static void SetProgress(Vector2Int c, float p) => buildProgress[c] = p;
public static int Delivered(Vector2Int c) => delivered.TryGetValue(c, out var v) ? v : 0;
public static int Remaining(Vector2Int c) { BlueprintCost(c, out var res, out var cost); return Mathf.Max(0, cost - Delivered(c)); }
public static void AddDelivered(Vector2Int c, int n) => delivered[c] = Delivered(c) + n;
public static void ClearBuild(Vector2Int c) { builders.Remove(c); buildProgress.Remove(c); delivered.Remove(c); }
GameObject ghost;
SpriteRenderer ghostSr;
BuildItem lastItem;
Vector2Int last = new Vector2Int(-9999, -9999);
bool dragWalls;
Vector2Int dragStart;
public static WallType GetBlueprintType(Vector2Int c) => blueprintTypes.TryGetValue(c, out var t) ? t : WallType.Wood;
public static BuildKind GetBlueprintKind(Vector2Int c) => blueprintKinds.TryGetValue(c, out var k) ? k : BuildKind.Wall;
public static void BlueprintCost(Vector2Int c, out ResourceType res, out int cost)
{
var kind = GetBlueprintKind(c);
var wt = GetBlueprintType(c);
res = ResourceType.Wood; cost = 10;
foreach (var it in items)
{
if (it.kind != kind) continue;
if (kind == BuildKind.Wall && it.wallType != wt) continue;
res = it.costType; cost = it.cost; break;
}
}
void Awake()
{
JobQueue.Clear();
blueprints.Clear(); blueprintTypes.Clear(); blueprintKinds.Clear(); designated.Clear();
builders.Clear(); buildProgress.Clear(); delivered.Clear();
items.Clear();
items.Add(new BuildItem { name = "Деревянная стена", category = "База", prefab = woodWallPrefab, costType = ResourceType.Wood, cost = WoodCost, wallType = WallType.Wood });
items.Add(new BuildItem { name = "Каменная стена", category = "База", prefab = stoneWallPrefab, costType = ResourceType.Stone, cost = StoneCost, wallType = WallType.Stone });
items.Add(new BuildItem { name = "Дверь", category = "База", prefab = doorPrefab, costType = ResourceType.Wood, cost = 10, kind = BuildKind.Door });
items.Add(new BuildItem { name = "Кровать", category = "Мебель", prefab = bedPrefab, costType = ResourceType.Wood, cost = 20, kind = BuildKind.Bed });
items.Add(new BuildItem { name = "Койка", category = "Мебель", prefab = cotPrefab, costType = ResourceType.Wood, cost = 15, kind = BuildKind.Cot });
items.Add(new BuildItem { name = "Стол исследований", category = "Исследования", prefab = deskPrefab, costType = ResourceType.Wood, cost = 30, kind = BuildKind.Desk });
}
public static void SelectItem(BuildItem item) { Current = item; IsActive = true; }
public static void Deactivate() { IsActive = false; Current = null; }
public static bool CanAffordCurrent()
{
if (Current == null) return false;
return Current.costType == ResourceType.Wood ? Storage.wood >= Current.cost : Storage.stone >= Current.cost;
}
void Update()
{
if ((Input.GetKeyDown(KeyCode.Escape) || Input.GetMouseButtonDown(1)) && IsActive) { Deactivate(); return; }
if (!IsActive || Current == null || StockpileMode.IsActive) { if (ghost != null) { Destroy(ghost); ghost = null; } return; }
if (GameUI.BlockInput) return;
if (ghost == null || lastItem != Current)
{
if (ghost != null) Destroy(ghost);
ghost = null; EnsureGhost(); lastItem = Current; last = new Vector2Int(-9999, -9999);
}
if (ghost == null) return;
Vector2Int c = WorldGrid.MouseCoord();
if (c != last)
{
last = c;
ghost.transform.position = new Vector3(c.x, c.y, 0);
ghostSr.color = CanPlace(c) ? new Color(0f, 1f, 0f, 0.5f) : new Color(1f, 0f, 0f, 0.5f);
}
if (Input.GetMouseButtonDown(0)) { dragWalls = true; dragStart = c; PlaceLine(c, c); }
else if (dragWalls && Input.GetMouseButton(0)) PlaceLine(dragStart, c);
if (Input.GetMouseButtonUp(0)) dragWalls = false;
}
void PlaceLine(Vector2Int a, Vector2Int b)
{
int dx = b.x - a.x, dy = b.y - a.y;
if (Mathf.Abs(dx) >= Mathf.Abs(dy))
{
int s = dx >= 0 ? 1 : -1;
for (int x = a.x; x != b.x + s; x += s) PlaceIfCan(new Vector2Int(x, a.y));
}
else
{
int s = dy >= 0 ? 1 : -1;
for (int y = a.y; y != b.y + s; y += s) PlaceIfCan(new Vector2Int(a.x, y));
}
}
void PlaceIfCan(Vector2Int c)
{
if (!CanPlace(c)) return;
GameObject bp = Instantiate(Current.prefab, new Vector3(c.x, c.y, 0), Quaternion.identity);
SpriteRenderer r = bp.GetComponent<SpriteRenderer>();
r.color = new Color(0.3f, 0.7f, 1f, 0.5f);
r.sortingOrder = 1;
blueprints[c] = bp;
blueprintTypes[c] = Current.wallType;
blueprintKinds[c] = Current.kind;
designated.Add(c);
buildProgress[c] = 0f;
if (Current.kind == BuildKind.Wall)
{
WorldGrid.SetBlocked(c);
var wat = bp.GetComponent<WallAutoTile>();
if (wat != null) WorldGrid.RegisterWall(c, wat);
}
JobQueue.Add(JobType.Build, c);
}
void EnsureGhost()
{
if (Current == null || Current.prefab == null) return;
ghost = Instantiate(Current.prefab);
ghostSr = ghost.GetComponent<SpriteRenderer>();
ghostSr.sortingOrder = 10;
}
bool CanPlace(Vector2Int c)
{
if (!WorldGrid.InBounds(c) || WorldGrid.IsBlocked(c) || designated.Contains(c)) return false;
if (WorldGrid.IsBed(c) || WorldGrid.IsDesk(c) || WorldGrid.IsDoor(c)) return false;
foreach (var col in Colonist.all)
if (col.CurrentCoord() == c) return false;
return true;
}
}