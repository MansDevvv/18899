using System.Collections.Generic;
using UnityEngine;

public class SelectionManager : MonoBehaviour
{
    public static readonly List<Colonist> selected = new List<Colonist>();

    bool dragging;
    Vector3 dragStart;
    bool pressOverUI;

    void Update()
    {
        if (BuildMode.IsActive || StockpileMode.IsActive || DemolishMode.IsActive) return;

        if (Input.GetMouseButtonDown(0))
            pressOverUI = GameUI.BlockInput;

        if (pressOverUI)
        {
            if (Input.GetMouseButtonUp(0)) pressOverUI = false;
            return;
        }

        if (Input.GetMouseButtonDown(0))
        {
            dragging = true;
            dragStart = Input.mousePosition;
        }

        if (Input.GetMouseButtonUp(0))
        {
            dragging = false;
            Vector3 end = Input.mousePosition;
            float dist = (end - dragStart).magnitude;
            if (dist < 10f) HandleClick();
            else BoxSelect(dragStart, end);
        }
    }

    void HandleClick()
    {
        Vector2Int c = WorldGrid.MouseCoord();
        bool shift = Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift);

        // колонист
        Colonist col = ColonistAt(c);
        if (col != null)
        {
            if (shift) { if (!selected.Contains(col)) { selected.Add(col); col.selected = true; } }
            else SetOnly(col);
            return;
        }

        var zone = WorldGrid.ZoneAt(c);
        if (zone != null && zone.type == ZoneType.Stockpile) { GameUI.Instance.manageZone = zone; return; }

        // дверь
        var door = WorldGrid.GetDoor(c);
        if (door != null) { door.SetOpenWorld(!door.isOpen); return; }

        // ягоды - назначить сбор
        var bush = BerryBush.At(c);
        if (bush != null && bush.hasBerries) { bush.designated = true; return; }

        // ресурс - назначить добычу
        var node = WorldGrid.GetResource(c);
        if (node != null) { JobQueue.Add(JobType.Harvest, c); return; }

                // иначе - приказ идти, растаскивая по разным клеткам
        if (!shift)
        {
            int i = 0;
            foreach (var s in selected)
            {
                s.OrderMove(SpreadTarget(c, i));
                i++;
            }
        }
    }

    void SetOnly(Colonist col)
    {
        foreach (var s in selected) s.selected = false;
        selected.Clear();
        selected.Add(col);
        col.selected = true;
    }

        // i-я свободная клетка вокруг цели, чтобы колонисты не слипались
    Vector2Int SpreadTarget(Vector2Int c, int index)
    {
        if (index == 0) return c;
        int count = 0;
        for (int r = 1; r <= 4; r++)
        {
            for (int dx = -r; dx <= r; dx++)
                for (int dy = -r; dy <= r; dy++)
                {
                    if (Mathf.Max(Mathf.Abs(dx), Mathf.Abs(dy)) != r) continue;
                    Vector2Int t = c + new Vector2Int(dx, dy);
                    if (!WorldGrid.InBounds(t) || WorldGrid.IsBlocked(t)) continue;
                    count++;
                    if (count == index) return t;
                }
        }
        return c;
    }

    Colonist ColonistAt(Vector2Int c)
    {
        foreach (var col in Colonist.all)
            if (col.CurrentCoord() == c) return col;
        return null;
    }

    void BoxSelect(Vector3 a, Vector3 b)
    {
        Rect r = Rect.MinMaxRect(
            Mathf.Min(a.x, b.x), Mathf.Min(a.y, b.y),
            Mathf.Max(a.x, b.x), Mathf.Max(a.y, b.y));

        foreach (var s in selected) s.selected = false;
        selected.Clear();

        foreach (var col in Colonist.all)
        {
            Vector3 sp = Camera.main.WorldToScreenPoint(col.transform.position);
            if (r.Contains(new Vector2(sp.x, sp.y)))
            {
                selected.Add(col);
                col.selected = true;
            }
        }
    }

        static Texture2D pxTex;

    void OnGUI()
    {
        if (!dragging) return;
        Vector3 e = Input.mousePosition;
        Rect r = Rect.MinMaxRect(
            Mathf.Min(dragStart.x, e.x), Screen.height - Mathf.Max(dragStart.y, e.y),
            Mathf.Max(dragStart.x, e.x), Screen.height - Mathf.Min(dragStart.y, e.y));

        if (pxTex == null)
        {
            pxTex = new Texture2D(1, 1);
            pxTex.SetPixel(0, 0, new Color(1f, 1f, 1f, 0.35f));
            pxTex.Apply();
        }

        float t = 2f;
        GUI.DrawTexture(new Rect(r.x, r.y, r.width, t), pxTex);          // верх
        GUI.DrawTexture(new Rect(r.x, r.y + r.height - t, r.width, t), pxTex); // низ
        GUI.DrawTexture(new Rect(r.x, r.y, t, r.height), pxTex);          // лево
        GUI.DrawTexture(new Rect(r.x + r.width - t, r.y, t, r.height), pxTex); // право
    }
}