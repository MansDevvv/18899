using System.Collections.Generic;
using UnityEngine;
// Иконка 1x1 над местом, где висит задача (чертёж, добыча, перенос, назначенный куст).
// Перетащи свой спрайт в поле Task Sprite на объекте со скриптом.
public class JobMarkers : MonoBehaviour
{
public Sprite taskSprite;
public int sortingOrder = 6;
public float bob = 0.06f;
readonly Dictionary<Vector2Int, GameObject> pool = new Dictionary<Vector2Int, GameObject>();
readonly HashSet<Vector2Int> wanted = new HashSet<Vector2Int>();
float timer;
void LateUpdate()
{
timer -= Time.deltaTime;
if (timer <= 0f) { timer = 0.25f; Rebuild(); }
float dy = Mathf.Sin(Time.time * 4f) * bob;
foreach (var kv in pool)
kv.Value.transform.position = new Vector3(kv.Key.x, kv.Key.y + 0.45f + dy, 0);
}
void Rebuild()
{
wanted.Clear();
if (taskSprite != null)
{
foreach (var j in JobQueue.Jobs) wanted.Add(j.coord);
foreach (var b in BerryBush.all) if (b.designated && b.hasBerries) wanted.Add(b.Coord);
}
var dead = new List<Vector2Int>();
foreach (var kv in pool)
if (!wanted.Contains(kv.Key)) { dead.Add(kv.Key); Destroy(kv.Value); }
foreach (var k in dead) pool.Remove(k);
foreach (var c in wanted)
if (!pool.ContainsKey(c))
{
var g = new GameObject("TaskIcon");
g.transform.SetParent(transform);
g.transform.position = new Vector3(c.x, c.y + 0.45f, 0);
var r = g.AddComponent<SpriteRenderer>();
r.sprite = taskSprite;
r.sortingOrder = sortingOrder;
pool[c] = g;
}
}
}