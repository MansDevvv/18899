using UnityEngine;

// Скорость игры: пауза / 1x / 2x / 3x
public static class GameSpeed
{
    public static int Speed { get; private set; } = 1;
    public static bool Paused { get; private set; }

    public static void SetSpeed(int s)
    {
        Speed = Mathf.Clamp(s, 1, 3);
        Paused = false;
        Apply();
    }

    public static void TogglePause()
    {
        Paused = !Paused;
        Apply();
    }

    // правая стрелка: 1 -> 2 -> 3 -> 1
    public static void Cycle()
    {
        SetSpeed(Speed >= 3 ? 1 : Speed + 1);
    }

    static void Apply()
    {
        Time.timeScale = Paused ? 0f : Speed;
    }

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void ResetSpeed()
    {
        Speed = 1;
        Paused = false;
        Time.timeScale = 1f;
    }
}