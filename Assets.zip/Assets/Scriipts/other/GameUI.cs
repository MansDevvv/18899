using System.Collections.Generic;
using UnityEngine;

public class GameUI : MonoBehaviour
{
    public static bool BlockInput { get; private set; }
    public static GameUI Instance;

    [Header("Иконки категорий")] public Sprite[] categoryIcons = new Sprite[7];
    [Header("Виньетка")]
    public bool vignetteEnabled = true;
    [Range(32, 512)] public int vignetteSize = 256;
    [Range(0f, 2f)] public float vignetteStrength = 1f;
    [Range(0.05f, 1f)] public float vignetteDarkness = 0.45f;

    readonly List<Rect> uiRects = new List<Rect>();
    readonly Dictionary<Colonist, int> tabs = new Dictionary<Colonist, int>();
    readonly Dictionary<Colonist, Vector2> scrollSkills = new Dictionary<Colonist, Vector2>();
    readonly Dictionary<Colonist, Vector2> scrollThoughts = new Dictionary<Colonist, Vector2>();
    readonly Dictionary<BuildMode.BuildItem, Sprite> itemIcons = new Dictionary<BuildMode.BuildItem, Sprite>();

    Vector2 scrollNames;
    Rect prRect = new Rect(8, 40, 300, 160);
    Rect mainWin = new Rect(60, 60, 400, 560);
    Rect socRect = new Rect(Screen.width - 390, 80, 370, 300);
    Colonist viewed;
    bool showNotes, showSociety, showZones;
    public StockpileZone manageZone;
    bool openRes = true, openFood = true;
    Rect zonesWinRect = new Rect(Screen.width / 2 - 130, Screen.height / 2 - 90, 260, 150);
    Rect manageWinRect = new Rect(Screen.width / 2 - 160, 140, 320, 360);
    float slide;
    int openCat = -1;
    Texture2D vignetteTex;
    int vignetteBuiltSize = -1;
    float vignetteBuiltDarkness = -1f;

    static readonly string[] Categories = { "База", "Освещение", "Еда", "Вода", "Медицина", "Мебель", "Исследования" };
    static readonly Color cHeader = new Color(0.63f, 0.21f, 0.40f);
    static readonly Color cPanel = new Color(0.94f, 0.93f, 0.90f);
    static readonly Color cDark = new Color(0.13f, 0.12f, 0.16f, 0.94f);
    static readonly Color cCell = new Color(0.24f, 0.23f, 0.28f);
    static readonly Color cText = new Color(0.16f, 0.15f, 0.20f);
    static readonly Color cTabOff = new Color(0.80f, 0.78f, 0.80f);
    static readonly Color cBarBg = new Color(0.80f, 0.79f, 0.78f);
    static readonly Color cSection = new Color(0.85f, 0.84f, 0.83f);

    GUIStyle stHeader, stHeaderBtn, stWin, stTabOn, stTabOff, stTextDark, stTextWhite, stWrap,
        stSection, stTop, stHint, stNotesBtn, stCell, stCellActive, stIconText, stNameSmall,
        stNote, stNoteBad;
    readonly Dictionary<Color, Texture2D> texCache = new Dictionary<Color, Texture2D>();

    void Awake() { Instance = this; }

    void Update()
    {
        GameTime.Tick(Time.deltaTime);
        if (Input.GetKeyDown(KeyCode.Tab)) showNotes = !showNotes;
        if (Input.GetKeyDown(KeyCode.H)) showSociety = !showSociety;
        if (Input.GetKeyDown(KeyCode.V)) StockpileMode.Begin(ZoneType.Stockpile);
        if (Input.GetKeyDown(KeyCode.Space)) GameSpeed.TogglePause();
        if (Input.GetKeyDown(KeyCode.RightArrow)) GameSpeed.Cycle();
        slide = Mathf.MoveTowards(slide, showNotes ? 1f : 0f, Time.unscaledDeltaTime * 6f);
    }

    Texture2D Tex(Color c)
    {
        if (!texCache.TryGetValue(c, out Texture2D t)) { t = new Texture2D(1, 1); t.SetPixel(0, 0, c); t.Apply(); texCache[c] = t; }
        return t;
    }

    void EnsureStyles()
    {
        if (stHeader != null) return;
        stHeader = new GUIStyle { normal = { background = Tex(cHeader), textColor = Color.white }, fontSize = 15, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleLeft, padding = new RectOffset(8, 4, 4, 4) };
        stHeaderBtn = new GUIStyle(stHeader) { alignment = TextAnchor.MiddleCenter, padding = new RectOffset(0, 0, 0, 0) };
        stWin = new GUIStyle { normal = { background = Tex(cPanel), textColor = cText }, fontSize = 13 };
        stTabOn = new GUIStyle { normal = { background = Tex(Color.white), textColor = cText }, fontSize = 13, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
        stTabOff = new GUIStyle { normal = { background = Tex(cTabOff), textColor = cText }, fontSize = 13, alignment = TextAnchor.MiddleCenter };
        stTextDark = new GUIStyle { normal = { textColor = cText }, fontSize = 13, padding = new RectOffset(4, 2, 2, 2) };
        stTextWhite = new GUIStyle { normal = { textColor = Color.white }, fontSize = 13, padding = new RectOffset(4, 2, 2, 2) };
        stWrap = new GUIStyle(stTextDark) { wordWrap = true };
        stNote = new GUIStyle(stTextWhite) { wordWrap = true };
        stNoteBad = new GUIStyle(stTextWhite) { wordWrap = true, normal = { textColor = new Color(1f, 0.45f, 0.45f) } };
        stSection = new GUIStyle { normal = { background = Tex(cSection), textColor = cText }, fontSize = 12, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleLeft, padding = new RectOffset(6, 2, 2, 2) };
        stTop = new GUIStyle { normal = { background = Tex(cDark), textColor = Color.white }, fontSize = 15, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleLeft, padding = new RectOffset(10, 4, 4, 4) };
        stHint = new GUIStyle { normal = { background = Tex(cDark), textColor = Color.white }, fontSize = 13, alignment = TextAnchor.MiddleLeft, padding = new RectOffset(10, 4, 2, 2) };
        stNotesBtn = new GUIStyle(stHeader) { alignment = TextAnchor.MiddleCenter };
        stCell = new GUIStyle { normal = { background = Tex(cCell) } };
        stCellActive = new GUIStyle { normal = { background = Tex(cHeader) } };
        stIconText = new GUIStyle { normal = { textColor = Color.white }, fontSize = 20, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
        stNameSmall = new GUIStyle { normal = { textColor = Color.white }, fontSize = 10, alignment = TextAnchor.MiddleCenter, wordWrap = true };
    }

    void EnsureVignette()
    {
        if (vignetteTex != null && vignetteBuiltSize == vignetteSize && Mathf.Approximately(vignetteBuiltDarkness, vignetteDarkness)) return;
        int size = Mathf.Clamp(vignetteSize, 16, 512);
        if (vignetteTex != null && vignetteTex.width != size) Destroy(vignetteTex);
        if (vignetteTex == null) vignetteTex = new Texture2D(size, size, TextureFormat.RGBA32, false);
        vignetteTex.filterMode = FilterMode.Bilinear;
        Vector2 center = new Vector2(size / 2f, size / 2f);
        float maxR = size / 2f;
        for (int y = 0; y < size; y++)
            for (int x = 0; x < size; x++)
            {
                float d = Vector2.Distance(new Vector2(x, y), center) / maxR;
                float a = Mathf.SmoothStep(0.55f, 1.0f, d) * vignetteDarkness;
                vignetteTex.SetPixel(x, y, new Color(0f, 0f, 0f, a));
            }
        vignetteTex.Apply();
        vignetteBuiltSize = size;
        vignetteBuiltDarkness = vignetteDarkness;
    }

    Rect ClampToScreen(Rect r)
    {
        r.x = Mathf.Clamp(r.x, 60 - r.width, Screen.width - 60);
        r.y = Mathf.Clamp(r.y, 30, Screen.height - 60);
        return r;
    }

    void OnGUI() { try { OnGUIInner(); } catch (System.Exception e) { Debug.LogError("UI: " + e); } }

    void OnGUIInner()
    {
        EnsureStyles();
        uiRects.Clear();
        if (vignetteEnabled && vignetteStrength > 0.01f)
        {
            EnsureVignette();
            GUI.color = new Color(1f, 1f, 1f, vignetteStrength);
            GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), vignetteTex);
            GUI.color = Color.white;
        }
        Rect top = new Rect(0, 0, Screen.width, 30);
        GUI.Box(top, $"День {GameTime.Day}, {DayNightCycle.PhaseRu}    Дерево: {Storage.wood}    Камень: {Storage.stone}    Еда: {Storage.food}    Наука: {Storage.research:0}    Сид: {WorldGenerator.CurrentSeed}", stTop);
        uiRects.Add(top);
        DrawSpeedButtons();
        prRect = ClampToScreen(GUI.Window(9999, prRect, PriorityWindow, "", stWin));
        uiRects.Add(prRect);
        var sel = SelectionManager.selected;
        if (sel.Count > 0)
        {
            if (viewed == null || !sel.Contains(viewed)) viewed = sel[0];
            mainWin = ClampToScreen(GUI.Window(1000, mainWin, ColonistWindow, "", stWin));
            uiRects.Add(mainWin);
        }
        else viewed = null;
        DrawBuildBar();
        Rect notesBtn = new Rect(Screen.width - 170, 34, 160, 26);
        if (GUI.Button(notesBtn, $"События ({Notifier.notes.Count})", stNotesBtn)) showNotes = !showNotes;
        uiRects.Add(notesBtn);
        Rect socBtn = new Rect(Screen.width - 350, 34, 170, 26);
        if (GUI.Button(socBtn, "Общество (H)", stNotesBtn)) showSociety = !showSociety;
        uiRects.Add(socBtn);
        if (showSociety) { socRect = ClampToScreen(GUI.Window(1002, socRect, SocietyWindow, "", stWin)); uiRects.Add(socRect); }
        if (slide > 0.01f)
        {
            float w = 350f; float x = Screen.width - w * slide;
            Rect panel = new Rect(x, 66, w - 8, 440);
            GUI.Box(new Rect(panel.x, panel.y, panel.width, 26), "ПОСЛЕДНИЕ СОБЫТИЯ", stHeader);
            GUI.Box(new Rect(panel.x, panel.y + 26, panel.width, panel.height - 26), "", stWin);
            int shown = 0;
            for (int n = Notifier.notes.Count - 1; n >= 0 && shown < 10; n--, shown++)
            {
                var note = Notifier.notes[n];
                bool bad = note.text.Contains("срыв") || note.text.Contains("ПОГИБ") || note.text.Contains("заболел")
                    || note.text.Contains("поругал") || note.text.Contains("травм") || note.text.Contains("депресс")
                    || note.text.Contains("ЗАБАСТОВ") || note.text.Contains("накричал") || note.text.Contains("отравил");
                GUI.Label(new Rect(panel.x + 4, panel.y + 30 + shown * 40, panel.width - 8, 40), $"Д{note.day}: {note.text}", bad ? stNoteBad : stNote);
            }
            if (slide > 0.5f) uiRects.Add(panel);
        }
        if (showZones) { zonesWinRect = ClampToScreen(GUI.Window(1003, zonesWinRect, ZonesWindow, "", stWin)); uiRects.Add(zonesWinRect); }
        if (manageZone != null) { manageWinRect = ClampToScreen(GUI.Window(1004, manageWinRect, StockpileWindow, "", stWin)); uiRects.Add(manageWinRect); }
        DrawBuildProgress();
        DrawDropLabels();
        string hint;
        if (StockpileMode.IsActive) hint = "ОБЛАСТЬ: тяни ЛКМ - рамка | ПКМ/Esc - выход";
        else if (BuildMode.IsActive && BuildMode.Current != null) hint = $"СТРОИМ: {BuildMode.Current.name} ({BuildMode.Current.cost} {(BuildMode.Current.costType == ResourceType.Wood ? "дерева" : "камня")}) | ПКМ/Esc - выход";
        else if (DemolishMode.IsActive) hint = "СНОС: ЛКМ по стене/чертежу | ПКМ/Esc - выход";
        else hint = "ЛКМ: выбрать/идти/добыть | Shift+ЛКМ: добавить | ПКМ: снять | V: склад | X: снос | Tab: события | H: общество | Space: пауза | ->: скорость";
        Rect hr = new Rect(0, Screen.height - 26, Screen.width, 26);
        GUI.Box(hr, hint, stHint);
        uiRects.Add(hr);
        Vector2 m = new Vector2(Input.mousePosition.x, Screen.height - Input.mousePosition.y);
        BlockInput = false;
        foreach (Rect r in uiRects) if (r.Contains(m)) { BlockInput = true; break; }
        DrawHoverOutline();
    }

    void DrawHoverOutline()
    {
        if (BlockInput) return;
        Vector2Int hc = WorldGrid.MouseCoord();
        var hz = WorldGrid.ZoneAt(hc);
        if (hz != null && hz.type == ZoneType.Stockpile)
        {
            float pulse = 0.3f + 0.2f * Mathf.Sin(Time.time * 4f);
            Vector3 a = Camera.main.WorldToScreenPoint(new Vector3(hz.rect.xMin - 0.5f, hz.rect.yMin - 0.5f, 0));
            Vector3 b = Camera.main.WorldToScreenPoint(new Vector3(hz.rect.xMax - 0.5f, hz.rect.yMax - 0.5f, 0));
            Rect r = new Rect(a.x, Screen.height - b.y, b.x - a.x, b.y - a.y);
            float t = 2f;
            Color old = GUI.color;
            GUI.color = new Color(1f, 1f, 1f, pulse);
            GUI.DrawTexture(new Rect(r.x - t, r.y - t, r.width + 2 * t, t), Tex(Color.white));
            GUI.DrawTexture(new Rect(r.x - t, r.y + r.height, r.width + 2 * t, t), Tex(Color.white));
            GUI.DrawTexture(new Rect(r.x - t, r.y, t, r.height), Tex(Color.white));
            GUI.DrawTexture(new Rect(r.x + r.width, r.y, t, r.height), Tex(Color.white));
            GUI.color = old;
            return;
        }
        SpriteRenderer target = null;
        var wall = WorldGrid.GetWall(hc); if (wall != null) target = wall.GetComponent<SpriteRenderer>();
        if (target == null) { var rn = WorldGrid.GetResource(hc); if (rn != null) target = rn.GetComponent<SpriteRenderer>(); }
        if (target == null) { var dr = WorldGrid.GetDrop(hc); if (dr != null) target = dr.GetComponent<SpriteRenderer>(); }
        if (target == null) { var door = WorldGrid.GetDoor(hc); if (door != null) target = door.GetComponent<SpriteRenderer>(); }
        if (target == null) { var fo = WorldGrid.GetFurnObj(hc); if (fo != null) target = fo.GetComponent<SpriteRenderer>(); }
        if (target == null) { var bb = BerryBush.At(hc); if (bb != null) target = bb.GetComponent<SpriteRenderer>(); }
        if (target == null && BuildMode.blueprints.TryGetValue(hc, out var bgo)) target = bgo.GetComponent<SpriteRenderer>();
        if (target == null) foreach (var c in Colonist.all) if (c.CurrentCoord() == hc) { target = c.GetComponent<SpriteRenderer>(); break; }
        if (target == null) return;
        Bounds bd = target.bounds;
        Vector3 sa = Camera.main.WorldToScreenPoint(new Vector3(bd.min.x, bd.min.y, 0));
        Vector3 sb = Camera.main.WorldToScreenPoint(new Vector3(bd.max.x, bd.max.y, 0));
        Rect r2 = new Rect(sa.x, Screen.height - sb.y, sb.x - sa.x, sb.y - sa.y);
        float t2 = 2f;
        GUI.DrawTexture(new Rect(r2.x - t2, r2.y - t2, r2.width + 2 * t2, t2), Tex(Color.white));
        GUI.DrawTexture(new Rect(r2.x - t2, r2.y + r2.height, r2.width + 2 * t2, t2), Tex(Color.white));
        GUI.DrawTexture(new Rect(r2.x - t2, r2.y, t2, r2.height), Tex(Color.white));
        GUI.DrawTexture(new Rect(r2.x + r2.width, r2.y, t2, r2.height), Tex(Color.white));
    }

    void DrawSpeedButtons()
    {
        float bw = 46f, total = bw * 4 + 3 * 4;
        float x0 = (Screen.width - total) / 2f;
        Rect bar = new Rect(x0 - 4, 34, total + 8, 38);
        GUI.Box(bar, "", stTop);
        uiRects.Add(bar);
        string[] labels = { "||", ">", ">>", ">>>" };
        for (int i = 0; i < 4; i++)
        {
            Rect b = new Rect(x0 + i * (bw + 4), 38, bw, 30);
            bool active = i == 0 ? GameSpeed.Paused : (!GameSpeed.Paused && GameSpeed.Speed == i);
            GUIStyle st = new GUIStyle(stHeaderBtn) { normal = { background = Tex(active ? cHeader : cCell), textColor = Color.white }, fontSize = 14 };
            if (GUI.Button(b, labels[i], st)) { if (i == 0) GameSpeed.TogglePause(); else GameSpeed.SetSpeed(i); GUIUtility.keyboardControl = 0; }
        }
    }

    void DrawBuildBar()
    {
        float bw = 64f, total = bw * Categories.Length;
        float x0 = (Screen.width - total) / 2f, y0 = Screen.height - 26 - 70;
        Rect bar = new Rect(x0 - 6, y0 - 6, total + 12, 76);
        GUI.Box(bar, "", stTop);
        uiRects.Add(bar);
        for (int i = 0; i < Categories.Length; i++)
        {
            Rect cell = new Rect(x0 + i * bw, y0, bw, 64);
            bool open = openCat == i;
            if (GUI.Button(cell, "", open ? stCellActive : stCell)) openCat = open ? -1 : i;
            Rect iconR = new Rect(cell.x + 10, cell.y + 4, 44, 40);
            if (categoryIcons != null && i < categoryIcons.Length && categoryIcons[i] != null) DrawSprite(iconR, categoryIcons[i]);
            else GUI.Label(iconR, Categories[i].Substring(0, 1), stIconText);
            GUI.Label(new Rect(cell.x, cell.y + 46, bw, 16), Categories[i], stNameSmall);
        }
        if (openCat >= 0) DrawBuildPopup(x0, y0);
    }

    void DrawBuildPopup(float barX, float barY)
    {
        float W = 330, H = 330;
        float x = Mathf.Clamp(barX + openCat * 64 - 80, 8, Screen.width - W - 8);
        Rect pop = new Rect(x, barY - H - 14, W, H);
        GUI.Box(new Rect(pop.x, pop.y, W, 26), "  " + Categories[openCat].ToUpper(), stHeader);
        if (GUI.Button(new Rect(pop.x + W - 26, pop.y + 2, 24, 22), "X", stHeaderBtn)) { openCat = -1; return; }
        GUI.Box(new Rect(pop.x, pop.y + 26, W, H - 26), "", stWin);
        uiRects.Add(pop);
        int col = 0, row = 0;
        bool any = false;
        foreach (var item in BuildMode.items)
        {
            if (item.category != Categories[openCat]) continue;
            any = true;
            Rect cell = new Rect(pop.x + 8 + col * 106, pop.y + 34 + row * 122, 98, 114);
            bool active = BuildMode.IsActive && BuildMode.Current == item;
            if (GUI.Button(cell, "", active ? stCellActive : stCell)) BuildMode.SelectItem(item);
            Sprite ic = ItemIcon(item);
            if (ic != null) DrawSprite(new Rect(cell.x + 9, cell.y + 6, 80, 64), ic);
            GUIStyle nameSt = new GUIStyle(stTextDark) { alignment = TextAnchor.UpperCenter, wordWrap = true, fontSize = 11 };
            GUI.Label(new Rect(cell.x, cell.y + 74, 98, 38), $"{item.name}\n({item.cost} {(item.costType == ResourceType.Wood ? "дерева" : "камня")})", nameSt);
            col++;
            if (col >= 3) { col = 0; row++; }
        }
        if (!any) GUI.Label(new Rect(pop.x + 10, pop.y + 40, W - 20, 24), "Пока пусто", stTextDark);
        if (openCat == 0)
        {
            Rect zb = new Rect(pop.x + 8, pop.y + H - 34, 160, 26);
            if (GUI.Button(zb, "Области (V - склад)", stTabOff)) { showZones = true; openCat = -1; }
        }
    }

    Sprite ItemIcon(BuildMode.BuildItem item)
    {
        if (!itemIcons.TryGetValue(item, out Sprite s))
        {
            s = null;
            if (item.prefab != null) { var r = item.prefab.GetComponent<SpriteRenderer>(); if (r != null) s = r.sprite; }
            itemIcons[item] = s;
        }
        return s;
    }

    void DrawSprite(Rect r, Sprite s)
    {
        if (s == null || s.texture == null) return;
        Rect t = s.textureRect;
        float tw = s.texture.width, th = s.texture.height;
        Rect uv = new Rect(t.x / tw, t.y / th, t.width / tw, t.height / th);
        GUI.DrawTextureWithTexCoords(r, s.texture, uv);
    }

    void ZonesWindow(int id)
    {
        float W = 260;
        GUI.Box(new Rect(0, 0, W, 26), "ОБЛАСТИ - тяни рамку", stHeader);
        if (GUI.Button(new Rect(W - 26, 2, 24, 22), "X", stHeaderBtn)) { showZones = false; return; }
        if (GUI.Button(new Rect(8, 34, W - 16, 28), "Склад", stTabOff)) { StockpileMode.Begin(ZoneType.Stockpile); showZones = false; }
        if (GUI.Button(new Rect(8, 68, W - 16, 28), "Мусор", stTabOff)) { StockpileMode.Begin(ZoneType.Trash); showZones = false; }
        if (GUI.Button(new Rect(8, 102, W - 16, 28), "Огород", stTabOff)) { StockpileMode.Begin(ZoneType.Garden); showZones = false; }
        GUI.DragWindow(new Rect(0, 0, W, 26));
    }
    void StockpileWindow(int id)
    {
        float W = 320;
        GUI.Box(new Rect(0, 0, W, 26), $"СКЛАД #{manageZone.id} ({manageZone.rect.width}x{manageZone.rect.height})", stHeader);
        if (GUI.Button(new Rect(W - 26, 2, 24, 22), "X", stHeaderBtn)) { manageZone = null; return; }
        float y = 34;
        if (GUI.Button(new Rect(8, y, 146, 26), "Расширить", stTabOff))
            manageZone.rect = new RectInt(manageZone.rect.xMin - 1, manageZone.rect.yMin - 1, manageZone.rect.width + 2, manageZone.rect.height + 2);
        if (GUI.Button(new Rect(166, y, 146, 26), "Уменьшить", stTabOff))
            if (manageZone.rect.width > 1 && manageZone.rect.height > 1)
                manageZone.rect = new RectInt(manageZone.rect.xMin + 1, manageZone.rect.yMin + 1, manageZone.rect.width - 2, manageZone.rect.height - 2);
        y += 32;
        GUIStyle redBtn = new GUIStyle(stTabOff) { normal = { textColor = new Color(0.7f, 0.1f, 0.1f) } };
        if (GUI.Button(new Rect(8, y, W - 16, 26), "Удалить склад", redBtn)) { WorldGrid.RemoveZone(manageZone); manageZone = null; return; }
        y += 34;
        GUI.Label(new Rect(8, y, W - 16, 20), "Принимает:", stTextDark); y += 20;
        if (GUI.Button(new Rect(8, y, 20, 20), openRes ? "-" : "+", stTabOff)) openRes = !openRes;
        GUI.Label(new Rect(32, y, 120, 20), "Ресурсы", stTextDark); y += 22;
        if (openRes) { manageZone.acceptWood = CheckRow(ref y, "Дерево", manageZone.acceptWood); manageZone.acceptStone = CheckRow(ref y, "Камень", manageZone.acceptStone); }
        if (GUI.Button(new Rect(8, y, 20, 20), openFood ? "-" : "+", stTabOff)) openFood = !openFood;
        GUI.Label(new Rect(32, y, 120, 20), "Еда", stTextDark); y += 22;
        if (openFood) { manageZone.acceptBerries = CheckRow(ref y, "Ягоды", manageZone.acceptBerries); manageZone.acceptPoison = CheckRow(ref y, "Ядовитые", manageZone.acceptPoison); }
        GUIStyle grey = new GUIStyle(stTextDark) { normal = { textColor = new Color(0.5f, 0.5f, 0.5f) } };
        GUI.Label(new Rect(32, y, 200, 20), "Трупы (скоро)", grey); y += 22;
        GUI.Label(new Rect(32, y, 200, 20), "Оружие (скоро)", grey); y += 22;
        GUI.Label(new Rect(32, y, 200, 20), "Одежда (скоро)", grey);
        GUI.DragWindow(new Rect(0, 0, W, 26));
    }
    bool CheckRow(ref float y, string label, bool val)
    {
        if (GUI.Button(new Rect(24, y, 20, 20), val ? "x" : "", stTabOff)) val = !val;
        GUI.Label(new Rect(48, y, 200, 20), label, stTextDark);
        y += 22;
        return val;
    }

    void DrawDropLabels()
    {
        GUIStyle st = new GUIStyle(stTextWhite) { fontSize = 11, alignment = TextAnchor.MiddleCenter };
        foreach (var d in WorldGrid.AllDrops())
        {
            if (d == null) continue;
            Vector3 sp = Camera.main.WorldToScreenPoint(d.transform.position + new Vector3(0, -0.45f, 0));
            if (sp.z < 0) continue;
            GUI.Label(new Rect(sp.x - 20, Screen.height - sp.y, 40, 16), d.amount.ToString(), st);
        }
    }

    void DrawBuildProgress()
    {
        foreach (var c in Colonist.all)
        {
            Vector2Int at;
            float p;
            Color col;
            if (c.IsWorkingBuild) { at = c.JobCoord; p = BuildMode.GetProgress(at); col = new Color(0.2f, 0.8f, 0.3f); }
            else if (c.IsWorkingHarvest) { at = c.HarvestCoord; p = c.WorkProgress; col = new Color(0.8f, 0.6f, 0.2f); }
            else continue;
            Vector3 sp = Camera.main.WorldToScreenPoint(new Vector3(at.x, at.y + 0.7f, 0));
            if (sp.z < 0) continue;
            float x = sp.x, y = Screen.height - sp.y;
            Rect bg = new Rect(x - 25, y, 50, 7);
            GUI.DrawTexture(bg, Tex(cBarBg));
            GUI.DrawTexture(new Rect(bg.x, bg.y, bg.width * p, bg.height), Tex(col));
        }
    }

    void SocietyWindow(int id)
    {
        float W = 370;
        GUI.Box(new Rect(0, 0, W, 26), "ОБЩЕСТВО", stHeader);
        if (GUI.Button(new Rect(W - 26, 2, 24, 22), "X", stHeaderBtn)) { showSociety = false; return; }
        float y = 32;
        DrawClassRow(ref y, Colonist.SocialClass.Worker, "РАБОЧИЕ");
        DrawClassRow(ref y, Colonist.SocialClass.Bourgeoisie, "БУРЖУАЗИЯ");
        DrawClassRow(ref y, Colonist.SocialClass.Soldier, "АРМИЯ");
        GUI.Label(new Rect(8, y + 4, W - 16, 40), "Стресс класса = средний по всем.\nПроблема = самая частая негативная мысль.", new GUIStyle(stTextDark) { fontSize = 11 });
        GUI.DragWindow(new Rect(0, 0, W, 26));
    }

    void DrawClassRow(ref float y, Colonist.SocialClass cls, string title)
    {
        float W = 370;
        int count = 0;
        float stressSum = 0;
        var neg = new Dictionary<string, int>();
        foreach (var c in Colonist.all)
        {
            if (c.socialClass != cls) continue;
            count++;
            stressSum += c.stress;
            foreach (var t in c.thoughts) if (t.value < 0) neg[t.text] = neg.TryGetValue(t.text, out int v) ? v + 1 : 1;
        }
        GUI.Box(new Rect(8, y, W - 16, 20), title + (count > 0 ? $" ({count})" : ""), stSection);
        y += 24;
        if (count == 0)
        {
            GUI.Label(new Rect(10, y, W - 20, 20), cls == Colonist.SocialClass.Soldier ? "Нет солдат" : "никого нет", stTextDark);
            y += 24;
            return;
        }
        float avg = stressSum / count;
        Color sc = avg > 70 ? new Color(0.8f, 0.15f, 0.15f) : avg > 40 ? new Color(0.85f, 0.5f, 0.1f) : new Color(0.1f, 0.5f, 0.2f);
        GUIStyle stStress = new GUIStyle(stTextDark) { normal = { textColor = sc }, fontStyle = FontStyle.Bold };
        GUI.Label(new Rect(10, y, W - 20, 20), $"Средний стресс: {avg:0}/100", stStress);
        y += 20;
        string top = "спокойно";
        int topN = 0;
        foreach (var kv in neg) if (kv.Value > topN) { topN = kv.Value; top = kv.Key; }
        GUI.Label(new Rect(10, y, W - 20, 20), $"Проблема: {top}" + (topN > 0 ? $" (x{topN})" : ""), stTextDark);
        y += 26;
    }

    Color PrioColor(int p) =>
        p <= 2 ? new Color(0.85f, 0.2f, 0.2f) : p <= 4 ? new Color(0.95f, 0.55f, 0.1f) :
        p <= 6 ? new Color(0.6f, 0.2f, 0.7f) : p <= 8 ? new Color(0.2f, 0.4f, 0.85f) : new Color(0.5f, 0.5f, 0.5f);

    void PriorityWindow(int id)
    {
        float W = 300;
        GUI.Box(new Rect(0, 0, W, 26), "РАБОТА", stHeader);
        var types = new List<JobType>(JobQueue.priority.Keys);
        types.Sort((a, b) => JobQueue.priority[a].CompareTo(JobQueue.priority[b]));
        float y = 32;
        foreach (JobType t in types)
        {
            int p = JobQueue.priority[t];
            GUIStyle num = new GUIStyle(stHeaderBtn) { normal = { background = Tex(PrioColor(p)), textColor = Color.white } };
            if (GUI.Button(new Rect(8, y, 30, 24), p.ToString(), num)) JobQueue.CyclePriority(t);
            GUI.Label(new Rect(44, y, W - 50, 24), Ru(t), stTextDark);
            y += 28;
        }
        GUI.Label(new Rect(8, y, W - 16, 20), "клик по числу - крутит 1..9", new GUIStyle(stTextDark) { fontSize = 11 });
        GUI.DragWindow(new Rect(0, 0, W, 26));
    }

    void ColonistWindow(int id)
    {
        float W = 400;
        var sel = SelectionManager.selected;
        GUI.Box(new Rect(0, 0, W, 26), $"Колонисты ({sel.Count})", stHeader);
        if (GUI.Button(new Rect(W - 26, 2, 24, 22), "X", stHeaderBtn))
        {
            foreach (var o in Colonist.all) o.selected = false;
            sel.Clear();
            viewed = null;
            return;
        }
        Rect namesView = new Rect(0, 26, W, 28);
        scrollNames = GUI.BeginScrollView(namesView, scrollNames, new Rect(0, 0, sel.Count * 96, 28));
        for (int i = 0; i < sel.Count; i++)
        {
            Colonist c = sel[i];
            if (c == null) continue;
            if (GUI.Button(new Rect(i * 96 + 2, 2, 92, 24), c.pname, c == viewed ? stTabOn : stTabOff)) viewed = c;
        }
        GUI.EndScrollView();
        if (viewed == null) { GUI.DragWindow(new Rect(0, 0, W, 26)); return; }
        if (!tabs.ContainsKey(viewed)) tabs[viewed] = 0;
        string[] tabNames = { "Статус", "Био", "Черты" };
        for (int i = 0; i < 3; i++)
            if (GUI.Button(new Rect(i * (W / 3), 54, W / 3, 24), tabNames[i], tabs[viewed] == i ? stTabOn : stTabOff)) tabs[viewed] = i;
        float y = 84;
        if (tabs[viewed] == 0) DrawStatus(viewed, y);
        else if (tabs[viewed] == 1) DrawBio(viewed, y);
        else DrawTraits(viewed, y);
        GUI.DragWindow(new Rect(0, 0, W, 26));
    }

    void DrawStatus(Colonist c, float y)
    {
        float iw = 384;
        GUI.Box(new Rect(8, y, iw, 20), "СОСТОЯНИЕ", stSection); y += 24;
        GUI.Label(new Rect(8, y, iw, 20), c.StatusText(), stTextDark); y += 20;
        GUI.Label(new Rect(8, y, iw, 20), c.JobInfo(), stTextDark); y += 20;
        GUI.Label(new Rect(8, y, iw, 20), c.NextWant(), stTextDark); y += 26;
        GUI.Box(new Rect(8, y, iw, 20), "ПОТРЕБНОСТИ", stSection); y += 24;
        Bar(new Rect(10, y, iw - 4, 16), c.health / 100f, new Color(0.85f, 0.25f, 0.25f), $"Здоровье {c.health:0}"); y += 19;
        Bar(new Rect(10, y, iw - 4, 16), c.energy / 100f, new Color(0.95f, 0.75f, 0.1f), $"Энергия {c.energy:0}"); y += 19;
        Bar(new Rect(10, y, iw - 4, 16), c.sleepiness / 100f, new Color(0.35f, 0.35f, 0.75f), $"Сонливость {c.sleepiness:0}"); y += 19;
        Bar(new Rect(10, y, iw - 4, 16), c.food / 100f, new Color(0.5f, 0.8f, 0.3f), $"Еда {c.food:0}"); y += 19;
        Bar(new Rect(10, y, iw - 4, 16), c.fun / 100f, new Color(0.3f, 0.6f, 0.9f), $"Веселье {c.fun:0}"); y += 19;
        Bar(new Rect(10, y, iw - 4, 16), c.stress / 100f, new Color(0.7f, 0.3f, 0.8f), $"Стресс {c.stress:0}"); y += 19;
        Bar(new Rect(10, y, iw - 4, 16), c.stamina / c.MaxStaminaNow, new Color(0.2f, 0.75f, 0.6f), $"Стамина {c.stamina:0}/{c.MaxStaminaNow:0}"); y += 19;
        if (c.adrenaline > 1f) Bar(new Rect(10, y, iw - 4, 16), c.adrenaline / 100f, new Color(0.9f, 0.2f, 0.1f), $"Адреналин {c.adrenaline:0}");
    }

    void DrawBio(Colonist c, float y)
    {
        float iw = 384;
        GUI.Box(new Rect(8, y, iw, 20), "БИОГРАФИЯ", stSection); y += 24;
        GUI.Label(new Rect(8, y, iw, 66), c.backstory, stWrap); y += 70;
        GUI.Box(new Rect(8, y, iw, 20), "НАВЫКИ", stSection); y += 24;
        Rect view = new Rect(8, y, iw, 250);
        if (!scrollSkills.ContainsKey(c)) scrollSkills[c] = Vector2.zero;
        scrollSkills[c] = GUI.BeginScrollView(view, scrollSkills[c], new Rect(0, 0, iw - 16, 12 * 24));
        int row = 0;
        foreach (var kv in c.skills)
        {
            string extra = "";
            if (kv.Key == SkillType.Melee) extra = $" урон {Skills.MeleeDamage(kv.Value.level):0.#}, уворот {Skills.MeleeDodge(kv.Value.level):0}%";
            if (kv.Key == SkillType.Ranged) extra = $" попад. {Skills.RangedHit(kv.Value.level):0}%";
            GUI.Label(new Rect(0, row * 24, 140, 22), Skills.Ru(kv.Key), stTextDark);
            Bar(new Rect(140, row * 24 + 4, 100, 13), kv.Value.xp / 100f, new Color(0.3f, 0.7f, 0.7f), "");
            GUI.Label(new Rect(244, row * 24, 140, 22), $"ур. {kv.Value.level}{extra}", stTextDark);
            row++;
        }
        GUI.EndScrollView();
    }

    void DrawTraits(Colonist c, float y)
    {
        float iw = 384;
        GUI.Box(new Rect(8, y, iw, 20), "ХАРАКТЕР И КЛАСС", stSection); y += 24;
        GUI.Label(new Rect(8, y, iw, 20), $"Характер: {c.TraitRu()}", stTextDark); y += 20;
        GUI.Label(new Rect(8, y, iw, 20), $"Класс: {c.ClassRu()}", stTextDark); y += 20;
        if (c.socialClass != Colonist.SocialClass.Bourgeoisie)
        {
            if (GUI.Button(new Rect(8, y, 200, 24), c.socialClass == Colonist.SocialClass.Soldier ? "Вернуть в рабочие" : "Мобилизовать в армию", stTabOff))
                c.SetClass(c.socialClass == Colonist.SocialClass.Soldier ? Colonist.SocialClass.Worker : Colonist.SocialClass.Soldier);
        }
        else
        {
            if (GUI.Button(new Rect(8, y, 200, 24), c.isGeneral ? "Снять генерала" : "Назначить генералом", stTabOff)) c.ToggleGeneral();
        }
        y += 30;
        GUI.Label(new Rect(8, y, iw, 20), $"Настроение: {c.MoodText()} ({c.Mood:0})", stTextDark); y += 20;
        GUIStyle red = new GUIStyle(stTextDark) { normal = { textColor = new Color(0.8f, 0.15f, 0.15f) }, fontStyle = FontStyle.Bold };
        GUI.Label(new Rect(8, y, iw, 20), c.FlagsText(), c.FlagsText() == "здоров" ? stTextDark : red); y += 26;
        GUI.Box(new Rect(8, y, iw, 20), "МЫСЛИ", stSection); y += 24;
        Rect view = new Rect(8, y, iw, 190);
        if (!scrollThoughts.ContainsKey(c)) scrollThoughts[c] = Vector2.zero;
        scrollThoughts[c] = GUI.BeginScrollView(view, scrollThoughts[c], new Rect(0, 0, iw - 16, Mathf.Max(190, c.thoughts.Count * 22)));
        for (int i = 0; i < c.thoughts.Count; i++)
        {
            var t = c.thoughts[i];
            GUIStyle st = new GUIStyle(stTextDark) { normal = { textColor = t.value < 0 ? new Color(0.8f, 0.15f, 0.15f) : new Color(0.1f, 0.5f, 0.2f) } };
            GUI.Label(new Rect(0, i * 22, iw - 16, 22), $"• {t.text} ({t.value:+#;-#})", st);
        }
        GUI.EndScrollView();
    }

    void Bar(Rect rect, float fill, Color color, string label)
    {
        GUI.DrawTexture(rect, Tex(cBarBg));
        GUI.DrawTexture(new Rect(rect.x, rect.y, rect.width * Mathf.Clamp01(fill), rect.height), Tex(color));
        if (label != "") GUI.Label(new Rect(rect.x + 2, rect.y, rect.width, rect.height), label, stTextDark);
    }

    string Ru(JobType t) => t == JobType.Build ? "Стройка" : t == JobType.Harvest ? "Добыча" : "Перенос";
}