using UnityEngine;

public class Door : MonoBehaviour
{
    public enum Orient { Side, Bottom }
    public Orient orient = Orient.Side;
    public bool isOpen = false;

    [Header("Спрайты двери")]
    public Sprite sideClosed;
    public Sprite sideOpen;
    public Sprite bottomClosed;
    public Sprite bottomOpen;

    SpriteRenderer sr;
    public Vector2Int Coord => new Vector2Int(Mathf.RoundToInt(transform.position.x), Mathf.RoundToInt(transform.position.y));

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
        Refresh();
    }

    // выбирает ориентацию по соседям и ставит нужный спрайт
    public void Refresh()
    {
        bool lr = WallOrDoor(Coord + new Vector2Int(-1, 0)) || WallOrDoor(Coord + new Vector2Int(1, 0));
        bool ud = WallOrDoor(Coord + new Vector2Int(0, 1)) || WallOrDoor(Coord + new Vector2Int(0, -1));
        if (lr) orient = Orient.Side;
        else if (ud) orient = Orient.Bottom;
        Apply();
    }

    void Apply()
    {
        if (sr == null) return;
        sr.sprite = orient == Orient.Side
            ? (isOpen ? sideOpen : sideClosed)
            : (isOpen ? bottomOpen : bottomClosed);
    }

    bool WallOrDoor(Vector2Int n) => WorldGrid.IsWall(n) || WorldGrid.IsDoor(n);

    public void SetOpen(bool o)
    {
        if (isOpen == o) return;
        isOpen = o;
        Apply();
    }

    public void SetOpenWorld(bool o)
    {
        SetOpen(o);
        if (o) WorldGrid.SetFree(Coord); else WorldGrid.SetBlocked(Coord);
        WorldGrid.RecomputeRooms();
        RefreshNeighbors();
    }

    public void Register()
    {
        WorldGrid.AddDoor(Coord, this);
        WorldGrid.SetBlocked(Coord);
        WorldGrid.RecomputeRooms();
        Refresh();
        RefreshNeighbors();
    }

    public void Unregister()
    {
        WorldGrid.RemoveDoor(Coord);
        WorldGrid.SetFree(Coord);
        WorldGrid.RecomputeRooms();
        RefreshNeighbors();
    }

    void RefreshNeighbors()
    {
        WorldGrid.RefreshWall(Coord + new Vector2Int(1, 0));
        WorldGrid.RefreshWall(Coord + new Vector2Int(-1, 0));
        WorldGrid.RefreshWall(Coord + new Vector2Int(0, 1));
        WorldGrid.RefreshWall(Coord + new Vector2Int(0, -1));
    }
}