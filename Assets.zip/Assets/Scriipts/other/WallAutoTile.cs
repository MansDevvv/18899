using UnityEngine;

// Автотайлинг стены: 16 спрайтов по маске соседей (стены И двери считаются)
public class WallAutoTile : MonoBehaviour
{
    [Tooltip("16 спрайтов в порядке маски: 1=верх,2=право,4=низ,8=лево (см. таблицу)")]
    public Sprite[] variants;
    public ResourceType refundType = ResourceType.Wood;

    SpriteRenderer sr;
    public Vector2Int Coord => new Vector2Int(Mathf.RoundToInt(transform.position.x), Mathf.RoundToInt(transform.position.y));

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
        Refresh();
    }

    public void Refresh()
    {
        if (sr == null || variants == null || variants.Length < 16) return;
        int m = 0;
        if (Conn(Coord + new Vector2Int(0, 1)))  m |= 1;  // верх
        if (Conn(Coord + new Vector2Int(1, 0)))  m |= 2;  // право
        if (Conn(Coord + new Vector2Int(0, -1))) m |= 4;  // низ
        if (Conn(Coord + new Vector2Int(-1, 0))) m |= 8;  // лево
        sr.sprite = variants[m];
    }

    bool Conn(Vector2Int n) => WorldGrid.IsWall(n) || WorldGrid.IsDoor(n);
}