using System.Collections.Generic;
using UnityEngine;

public static class Pathfinding
{
    public static List<Vector2Int> FindPath(Vector2Int from, Vector2Int to)
    {
        if (!WorldGrid.InBounds(to) || !WorldGrid.IsPathPassable(to)) return null;
        if (from == to) return new List<Vector2Int>();

        var open = new List<Vector2Int> { from };
        var came = new Dictionary<Vector2Int, Vector2Int>();
        var g = new Dictionary<Vector2Int, float> { { from, 0 } };
        var closed = new HashSet<Vector2Int>();

        while (open.Count > 0)
        {
            int bi = 0; float bf = float.MaxValue;
            for (int i = 0; i < open.Count; i++)
            {
                float f = g[open[i]] + Heur(open[i], to);
                if (f < bf) { bf = f; bi = i; }
            }
            var cur = open[bi];
            open.RemoveAt(bi);
            if (cur == to) return Reconstruct(came, from, to);
            closed.Add(cur);

            foreach (var n in N8(cur))
            {
                if (!WorldGrid.IsPathPassable(n) || closed.Contains(n)) continue;
                // не срезать угол между двумя стенами
                int dx = n.x - cur.x, dy = n.y - cur.y;
                if (dx != 0 && dy != 0)
                {
                    if (!WorldGrid.IsPathPassable(new Vector2Int(cur.x + dx, cur.y)) ||
                        !WorldGrid.IsPathPassable(new Vector2Int(cur.x, cur.y + dy))) continue;
                }
                float step = (dx != 0 && dy != 0) ? 1.4f : 1f;
                float ng = g[cur] + step;
                if (!g.TryGetValue(n, out float og) || ng < og)
                {
                    g[n] = ng; came[n] = cur;
                    if (!open.Contains(n)) open.Add(n);
                }
            }
        }
        return null;
    }

    static float Heur(Vector2Int a, Vector2Int b) => Mathf.Max(Mathf.Abs(a.x - b.x), Mathf.Abs(a.y - b.y));

    static List<Vector2Int> Reconstruct(Dictionary<Vector2Int, Vector2Int> came, Vector2Int from, Vector2Int to)
    {
        var path = new List<Vector2Int>();
        var c = to;
        while (c != from) { path.Add(c); c = came[c]; }
        path.Reverse();
        return path;
    }

    static Vector2Int[] N8(Vector2Int c) => new[]
    {
        new Vector2Int(c.x+1,c.y), new Vector2Int(c.x-1,c.y), new Vector2Int(c.x,c.y+1), new Vector2Int(c.x,c.y-1),
        new Vector2Int(c.x+1,c.y+1), new Vector2Int(c.x+1,c.y-1), new Vector2Int(c.x-1,c.y+1), new Vector2Int(c.x-1,c.y-1),
    };
}