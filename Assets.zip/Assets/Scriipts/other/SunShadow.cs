using System.Collections.Generic;
using UnityEngine;

// Тень-проекция как в RimWorld: силуэт объекта, скошенный в сторону солнца.
// Внутри помещений тени нет.
public class SunShadow : MonoBehaviour
{
    [Range(0f, 0.6f)] public float alpha = 0.3f;
    public float rise = 0.25f;   // рассвет
    public float set = 0.80f;    // закат
    public bool onlyOutdoor = true; // не рисовать тень в помещении

    SpriteRenderer parentSr;
    MeshFilter mf; MeshRenderer mr; Mesh mesh;
    Sprite lastSprite; Material mat;

    static readonly Dictionary<Texture2D, Material> mats = new Dictionary<Texture2D, Material>();

    Vector2Int Cell => new Vector2Int(Mathf.RoundToInt(transform.position.x), Mathf.RoundToInt(transform.position.y));

    void Awake()
    {
        parentSr = GetComponent<SpriteRenderer>();
        var go = new GameObject("Shadow");
        go.transform.SetParent(transform);
        go.transform.localPosition = new Vector3(0f, 0f, -0.05f); // чуть ближе к камере - поверх земли, под объектами
        mf = go.AddComponent<MeshFilter>();
        mr = go.AddComponent<MeshRenderer>();
        mr.sortingOrder = 0;
        mr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        mesh = new Mesh();
        mesh.vertices = new Vector3[4];              // сначала 4 вершины-заглушки
        mesh.triangles = new[] { 0, 2, 1, 0, 3, 2 }; // потом треугольники
        mf.sharedMesh = mesh;
    }

    void LateUpdate()
    {
        if (parentSr == null || parentSr.sprite == null) { mr.enabled = false; return; }
        if (onlyOutdoor && WorldGrid.IsIndoor(Cell)) { mr.enabled = false; return; }

        float dp = GameTime.DayPart;
        if (dp < rise || dp > set) { mr.enabled = false; return; }
        mr.enabled = true;

        float t = (dp - rise) / (set - rise);
        float dir = Mathf.Lerp(-1f, 1f, t);          // утро влево, вечер вправо
        float elev = Mathf.Sin(Mathf.PI * t);        // высота солнца
        float len = Mathf.Lerp(1.1f, 0.35f, elev);   // длина тени
        float shear = dir * Mathf.Lerp(1.1f, 0.15f, elev); // наклон

        var s = parentSr.sprite;
        if (s != lastSprite) { Rebuild(s); lastSprite = s; }
        if (mat == null) mat = GetMat(s.texture);
        mr.sharedMaterial = mat;
        mat.color = new Color(0f, 0f, 0f, alpha * Mathf.Clamp01(elev + 0.3f));

        // основание на низе объекта, верхушка уезжает в сторону солнца
        Bounds bb = s.bounds;
        Rect b = new Rect(bb.min.x, bb.min.y, bb.size.x, bb.size.y);
        float h = b.size.y;
        Vector3[] v = new Vector3[4];
        v[0] = new Vector3(b.min.x, b.min.y, 0);
        v[1] = new Vector3(b.max.x, b.min.y, 0);
        v[2] = new Vector3(b.max.x + shear * h, b.min.y + h * len, 0);
        v[3] = new Vector3(b.min.x + shear * h, b.min.y + h * len, 0);
        mesh.vertices = v;
        mesh.RecalculateBounds();
    }

    void Rebuild(Sprite s)
    {
        Rect r = s.textureRect;
        float tw = s.texture.width, th = s.texture.height;
        mesh.uv = new[]
        {
            new Vector2(r.x / tw, r.y / th),
            new Vector2((r.x + r.width) / tw, r.y / th),
            new Vector2((r.x + r.width) / tw, (r.y + r.height) / th),
            new Vector2(r.x / tw, (r.y + r.height) / th),
        };
    }

    static Material GetMat(Texture2D tex)
    {
        // m == null ловит уничтоженный после Stop материал
        if (!mats.TryGetValue(tex, out var m) || m == null)
        {
            var sh = Shader.Find("Sprites/Default");
            if (sh == null) sh = Shader.Find("Unlit/Transparent");
            m = new Material(sh);
            m.mainTexture = tex;
            mats[tex] = m;
        }
        return m;
    }

    // чистим кэш при каждом запуске Play, чтобы не держать мёртвые материалы
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    static void ClearCache() { mats.Clear(); }
}