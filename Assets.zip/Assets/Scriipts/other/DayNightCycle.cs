using UnityEngine;
using UnityEngine.Rendering.Universal;
public class DayNightCycle : MonoBehaviour
{
    public Light2D light2D;
    [Header("Длительность фаз (минуты)")]
    public float dayMinutes = 16f;
    public float nightMinutes = 10f;
    [Header("Цвета")]
    public Color night = new Color(0.25f, 0.3f, 0.55f);
    public Color dawn = new Color(1f, 0.6f, 0.35f);
    public Color day = Color.white;
    public Color dusk = new Color(0.9f, 0.45f, 0.3f);
    [Tooltip("Насколько темно ночью")] public float nightIntensity = 0.35f;
    public static string PhaseRu { get; private set; } = "день";
    void Awake()
    {
        if (light2D == null) light2D = FindAnyObjectByType<Light2D>();
        GameTime.dayLength = (dayMinutes + nightMinutes) * 60f;
    }
    void Update()
    {
        if (light2D == null) return;
        float total = dayMinutes + nightMinutes;
        float dayFrac = dayMinutes / total;
        float trans = 1f / total; // ~1 минута на рассвет/закат
        float t = GameTime.DayPart; // 0 = утро
        Color col; float inten;
        if (t < dayFrac)
        {
            if (t < trans) { float k = t / trans; col = Color.Lerp(night, dawn, k); inten = Mathf.Lerp(nightIntensity, 0.9f, k); PhaseRu = "рассвет"; }
            else if (t < trans * 2f) { float k = (t - trans) / trans; col = Color.Lerp(dawn, day, k); inten = Mathf.Lerp(0.9f, 1f, k); PhaseRu = "утро"; }
            else if (t > dayFrac - trans) { float k = (t - (dayFrac - trans)) / trans; col = Color.Lerp(day, dusk, k); inten = Mathf.Lerp(1f, 0.8f, k); PhaseRu = "вечер"; }
            else { col = day; inten = 1f; PhaseRu = "день"; }
        }
        else
        {
            float k = Mathf.Clamp01((t - dayFrac) / trans);
            if (k < 1f) { col = Color.Lerp(dusk, night, k); inten = Mathf.Lerp(0.8f, nightIntensity, k); PhaseRu = "вечер"; }
            else { col = night; inten = nightIntensity; PhaseRu = "ночь"; }
        }
        light2D.color = col;
        light2D.intensity = inten;
    }
}