using System.Collections.Generic;
using UnityEngine;

public class WorldGenerator : MonoBehaviour
{
    public GameObject tilePrefab;
    public GameObject treePrefab;
    public GameObject rockPrefab;
    public GameObject pawnPrefab;
    public GameObject berryGoodPrefab;
    public GameObject berryPoisonPrefab;

    public int width = 200;
    public int height = 200;
    public int treeCount = 60;
    public int rockCount = 30;
    public int berryGoodCount = 15;
    public int berryPoisonCount = 8;
    public int colonistCount = 10;
    public int bourgeoisieCount = 3;
    public int minResourceGap = 2;
    public int clearRadius = 4;
    public int chunkSize = 50;

    [Header("Сид мира")]
    public bool randomSeed = true;
    public int seed;

    [Header("Каменные зоны")]
    public Sprite stoneGroundSprite;   // текстура камня для земли
    [Range(0f, 1f)] public float stoneLo = 0.45f; // ниже - трава
    [Range(0f, 1f)] public float stoneHi = 0.55f; // выше - камень
    public float stoneScale = 0.08f;   // размер пятен (меньше = крупнее)

    [Header("Декорации")]
    public Sprite grassDecor1;
    public Sprite grassDecor2;
    public Sprite stoneDecor1;
    public Sprite stoneDecor2;
    public int grassDecorCount = 150;
    public int stoneDecorCount = 40;

    public static int CurrentSeed { get; private set; }

    System.Random rng;
    Vector2Int center;
    readonly HashSet<Vector2Int> decorUsed = new HashSet<Vector2Int>();

    void Start()
    {
        CurrentSeed = randomSeed ? Random.Range(-1000000, 1000001) : seed;
        rng = new System.Random(CurrentSeed);
        Debug.Log("Сид мира: " + CurrentSeed);

        Storage.Clear();
        JobQueue.Clear();
        WorldGrid.ClearAll();
        WorldGrid.SetSize(width, height);
        decorUsed.Clear();

        GenerateGround();

        center = new Vector2Int(width / 2, height / 2);

        SpawnDecor(grassDecor1, grassDecorCount / 2, false);
        SpawnDecor(grassDecor2, grassDecorCount / 2, false);
        SpawnDecor(stoneDecor1, stoneDecorCount / 2, true);
        SpawnDecor(stoneDecor2, stoneDecorCount / 2, true);

        Spawn(treePrefab, treeCount, ResourceType.Wood, center, false);
        Spawn(rockPrefab, rockCount, ResourceType.Stone, center, true);

        SpawnBerry(berryGoodPrefab, berryGoodCount, center);
        SpawnBerry(berryPoisonPrefab, berryPoisonCount, center);

        int bourg = Mathf.Min(bourgeoisieCount, colonistCount);
        for (int i = 0; i < colonistCount; i++)
        {
            Vector2Int p = center + new Vector2Int(Rng(-3, 4), Rng(-3, 4));
            GameObject g = Instantiate(pawnPrefab, new Vector3(p.x, p.y, 0), Quaternion.identity);
            Colonist col = g.GetComponent<Colonist>();
            col.socialClass = i < bourg ? Colonist.SocialClass.Bourgeoisie : Colonist.SocialClass.Worker;
                    col.RefreshSprites();
        }
        if (FindAnyObjectByType<RoofDarkness>() == null)
            new GameObject("RoofDarkness").AddComponent<RoofDarkness>();
    }

    int Rng(int min, int max) => rng.Next(min, max);
    float Rng01() => (float)rng.NextDouble();

    void GenerateGround()
    {
        SpriteRenderer pr = tilePrefab.GetComponent<SpriteRenderer>();
        Sprite gs = pr.sprite;
        Material grassMat = new Material(pr.sharedMaterial);
        grassMat.mainTexture = gs.texture;

        Material stoneMat = null;
        if (stoneGroundSprite != null)
        {
            stoneMat = new Material(pr.sharedMaterial);
            stoneMat.mainTexture = stoneGroundSprite.texture;
        }

        int chunksX = Mathf.CeilToInt(width / (float)chunkSize);
        int chunksY = Mathf.CeilToInt(height / (float)chunkSize);
        for (int cy = 0; cy < chunksY; cy++)
            for (int cx = 0; cx < chunksX; cx++)
                BuildChunk(cx, cy, gs, grassMat, stoneGroundSprite, stoneMat);
    }

    void BuildChunk(int cx, int cy, Sprite gs, Material gm, Sprite ss, Material sm)
    {
        int x0 = cx * chunkSize, y0 = cy * chunkSize;
        int x1 = Mathf.Min(x0 + chunkSize, width);
        int y1 = Mathf.Min(y0 + chunkSize, height);

        var gv = new List<Vector3>(); var gu = new List<Vector2>(); var gt = new List<int>();
        var sv = new List<Vector3>(); var su = new List<Vector2>(); var st = new List<int>();

        Texture2D gtex = gs.texture; Rect gr = gs.textureRect;
        float gu0 = gr.x / gtex.width, gv0 = gr.y / gtex.height;
        float gu1 = (gr.x + gr.width) / gtex.width, gv1 = (gr.y + gr.height) / gtex.height;

        Texture2D stex = ss != null ? ss.texture : gtex; Rect sr = ss != null ? ss.textureRect : gr;
        float su0 = sr.x / stex.width, sv0 = sr.y / stex.height;
        float su1 = (sr.x + sr.width) / stex.width, sv1 = (sr.y + sr.height) / stex.height;

        for (int y = y0; y < y1; y++)
            for (int x = x0; x < x1; x++)
            {
                bool stone = sm != null && IsStone(x, y);
                var v = stone ? sv : gv; var u = stone ? su : gu; var t = stone ? st : gt;
                float u0 = stone ? su0 : gu0, v0 = stone ? sv0 : gv0;
                float u1 = stone ? su1 : gu1, v1 = stone ? sv1 : gv1;

                int vi = v.Count;
                v.Add(new Vector3(x, y, 0)); v.Add(new Vector3(x + 1, y, 0));
                v.Add(new Vector3(x + 1, y + 1, 0)); v.Add(new Vector3(x, y + 1, 0));
                SetUVList(u, vi, u0, v0, u1, v1, Rng(0, 4));
                t.Add(vi); t.Add(vi + 2); t.Add(vi + 1);
                t.Add(vi); t.Add(vi + 3); t.Add(vi + 2);
            }

        GameObject parent = new GameObject("GroundChunk_" + cx + "_" + cy);
        parent.transform.SetParent(transform);
        if (gv.Count > 0) MakeMesh(parent, gv, gu, gt, gm, "grass");
        if (sv.Count > 0 && sm != null) MakeMesh(parent, sv, su, st, sm, "stone");
    }

    void MakeMesh(GameObject parent, List<Vector3> v, List<Vector2> u, List<int> t, Material m, string sub)
    {
        Mesh mesh = new Mesh { name = sub };
        mesh.vertices = v.ToArray();
        mesh.uv = u.ToArray();
        mesh.triangles = t.ToArray();
        var n = new Vector3[v.Count];
        for (int i = 0; i < n.Length; i++) n[i] = Vector3.back;
        mesh.normals = n;

        GameObject g = new GameObject(sub);
        g.transform.SetParent(parent.transform);
        g.AddComponent<MeshFilter>().sharedMesh = mesh;
        var mr = g.AddComponent<MeshRenderer>();
        mr.sharedMaterial = m;
        mr.sortingOrder = -1; // земля ниже теней
    }

    // ===== шум для каменных зон =====
    bool IsStone(int x, int y)
    {
        float n = Noise(x, y);
        // широкая мягкая полоса перехода между lo и hi
        float t = Mathf.Clamp01((n - stoneLo) / Mathf.Max(0.001f, stoneHi - stoneLo));
        t = t * t * (3 - 2 * t);
        return Rng01() < t;
    }

        // камень ли это место (для спавна)
    public bool IsStoneGround(int x, int y) => Noise(x, y) > stoneLo;

    float Noise(int x, int y)
    {
        float xf = x * stoneScale, yf = y * stoneScale;
        int x0 = Mathf.FloorToInt(xf), y0 = Mathf.FloorToInt(yf);
        float tx = xf - x0, ty = yf - y0;
        tx = tx * tx * (3 - 2 * tx); ty = ty * ty * (3 - 2 * ty);
        float a = Hash01(x0, y0), b = Hash01(x0 + 1, y0);
        float c = Hash01(x0, y0 + 1), d = Hash01(x0 + 1, y0 + 1);
        return Mathf.Lerp(Mathf.Lerp(a, b, tx), Mathf.Lerp(c, d, tx), ty);
    }

    float Hash01(int x, int y)
    {
        int h = x * 374761393 + y * 668265263 + CurrentSeed * 144665;
        h = (h ^ (h >> 13)) * 1274126177;
        return ((h ^ (h >> 16)) & 0x7fffffff) / (float)0x7fffffff;
    }

    void SetUVList(List<Vector2> uvs, int vi, float u0, float v0, float u1, float v1, int rot)
    {
        switch (rot)
        {
            case 0: uvs.Add(new Vector2(u0,v0)); uvs.Add(new Vector2(u1,v0)); uvs.Add(new Vector2(u1,v1)); uvs.Add(new Vector2(u0,v1)); break;
            case 1: uvs.Add(new Vector2(u1,v0)); uvs.Add(new Vector2(u1,v1)); uvs.Add(new Vector2(u0,v1)); uvs.Add(new Vector2(u0,v0)); break;
            case 2: uvs.Add(new Vector2(u1,v1)); uvs.Add(new Vector2(u0,v1)); uvs.Add(new Vector2(u0,v0)); uvs.Add(new Vector2(u1,v0)); break;
            default: uvs.Add(new Vector2(u0,v1)); uvs.Add(new Vector2(u0,v0)); uvs.Add(new Vector2(u1,v0)); uvs.Add(new Vector2(u1,v1)); break;
        }
    }

    void SetUV(Vector2[] uvs, int vi, float u0, float v0, float u1, float v1, int rot)
    {
        switch (rot)
        {
            case 0: uvs[vi]=new Vector2(u0,v0); uvs[vi+1]=new Vector2(u1,v0); uvs[vi+2]=new Vector2(u1,v1); uvs[vi+3]=new Vector2(u0,v1); break;
            case 1: uvs[vi]=new Vector2(u1,v0); uvs[vi+1]=new Vector2(u1,v1); uvs[vi+2]=new Vector2(u0,v1); uvs[vi+3]=new Vector2(u0,v0); break;
            case 2: uvs[vi]=new Vector2(u1,v1); uvs[vi+1]=new Vector2(u0,v1); uvs[vi+2]=new Vector2(u0,v0); uvs[vi+3]=new Vector2(u1,v0); break;
            default: uvs[vi]=new Vector2(u0,v1); uvs[vi+1]=new Vector2(u0,v0); uvs[vi+2]=new Vector2(u1,v0); uvs[vi+3]=new Vector2(u1,v1); break;
        }
    }

    void SpawnDecor(Sprite spr, int count, bool onStone)
    {
        if (spr == null || count <= 0) return;
        int spawned = 0, tries = 0;
        while (spawned < count && tries < count * 100)
        {
            tries++;
            Vector2Int c = new Vector2Int(Rng(0, width), Rng(0, height));
            if ((c - center).sqrMagnitude < clearRadius * clearRadius) continue;
            if (IsStoneGround(c.x, c.y) != onStone) continue; // трава на траве, камень на камне
            if (WorldGrid.IsBlocked(c) || WorldGrid.GetResource(c) != null) continue;
            if (decorUsed.Contains(c)) continue;
            bool bad = false;
            for (int dx = -1; dx <= 1 && !bad; dx++)
                for (int dy = -1; dy <= 1 && !bad; dy++)
                    if (WorldGrid.GetResource(c + new Vector2Int(dx, dy)) != null) bad = true;
            if (bad) continue;

            decorUsed.Add(c);
            GameObject g = new GameObject("Decor_" + spr.name);
            g.transform.SetParent(transform);
            g.transform.position = new Vector3(c.x, c.y, 0);
            SpriteRenderer r = g.AddComponent<SpriteRenderer>();
            r.sprite = spr;
            r.sortingOrder = 1;
            if (Rng01() < 0.5f) r.flipX = true;
            spawned++;
        }
    }

    void Spawn(GameObject prefab, int count, ResourceType type, Vector2Int c0, bool onStone)
    {
        if (prefab == null) return;
        int spawned = 0, tries = 0;
        while (spawned < count && tries < count * 300)
        {
            tries++;
            Vector2Int c = new Vector2Int(Rng(0, width), Rng(0, height));
            if ((c - c0).sqrMagnitude < clearRadius * clearRadius) continue;
            if (IsStoneGround(c.x, c.y) != onStone) continue;
            if (WorldGrid.IsBlocked(c) || WorldGrid.GetResource(c) != null) continue;
            if (TooClose(c)) continue;
            GameObject g = Instantiate(prefab, new Vector3(c.x, c.y, 0), Quaternion.identity, transform);
            ResourceNode node = g.GetComponent<ResourceNode>();
            node.type = type;
            if (type == ResourceType.Wood) node.amount = Rng(9, 14);
            else if (type == ResourceType.Stone) node.amount = Rng(4, 9);
            node.Register();
            spawned++;
        }
    }

    void SpawnBerry(GameObject prefab, int count, Vector2Int c0)
    {
        if (prefab == null) return;
        int spawned = 0, tries = 0;
        while (spawned < count && tries < count * 200)
        {
            tries++;
            Vector2Int c = new Vector2Int(Rng(0, width), Rng(0, height));
            if ((c - c0).sqrMagnitude < clearRadius * clearRadius) continue;
            if (IsStoneGround(c.x, c.y)) continue; // ягоды только на траве
            if (WorldGrid.IsBlocked(c) || WorldGrid.GetResource(c) != null) continue;
            Instantiate(prefab, new Vector3(c.x, c.y, 0), Quaternion.identity, transform);
            spawned++;
        }
    }

    bool TooClose(Vector2Int c)
    {
        for (int dx = -minResourceGap; dx <= minResourceGap; dx++)
            for (int dy = -minResourceGap; dy <= minResourceGap; dy++)
                if (WorldGrid.GetResource(c + new Vector2Int(dx, dy)) != null) return true;
        return false;
    }
}