using UnityEngine;

// Камера как в ONI: плавный зум колесом к курсору, драг СКМ, WASD, край экрана
public class CameraController : MonoBehaviour
{
    public float panSpeed = 12f;
    public float zoomSpeed = 2f;
    public float minZoom = 2.5f;
    public float maxZoom = 15f;
    public bool clampToMap = true;
    public float margin = 0f;
    public bool edgeScrolling = true;
    public int edgeSize = 10;

    private Camera cam;
    private bool centered;
    private float targetSize;
    private Vector3 lastMouse;
    private bool dragging;

    void Awake()
    {
        cam = GetComponent<Camera>();
        targetSize = cam.orthographicSize;
    }

    void LateUpdate()
    {
        if (!centered && WorldGrid.Width > 0)
        {
            centered = true;
            transform.position = new Vector3(
                (WorldGrid.Width - 1f) * 0.5f,
                (WorldGrid.Height - 1f) * 0.5f,
                transform.position.z);
        }

        float zoomFactor = cam.orthographicSize / 5f;

        // драг средней кнопкой
        if (Input.GetMouseButtonDown(2)) { dragging = true; lastMouse = Input.mousePosition; }
        if (dragging && Input.GetMouseButton(2))
        {
            Vector3 delta = Input.mousePosition - lastMouse;
            float wppY = cam.orthographicSize * 2f / Screen.height;
            float wppX = cam.orthographicSize * 2f * cam.aspect / Screen.width;
            transform.position -= new Vector3(delta.x * wppX, delta.y * wppY, 0f);
            lastMouse = Input.mousePosition;
        }
        if (Input.GetMouseButtonUp(2)) dragging = false;

        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");
        transform.position += new Vector3(h, v, 0f) * panSpeed * zoomFactor * Time.unscaledDeltaTime;

        if (edgeScrolling && MouseInGameView() && !GameUI.BlockInput)
        {
            Vector3 e = Vector3.zero;
            if (Input.mousePosition.x <= edgeSize) e.x -= 1f;
            if (Input.mousePosition.x >= Screen.width - edgeSize) e.x += 1f;
            if (Input.mousePosition.y <= edgeSize) e.y -= 1f;
            if (Input.mousePosition.y >= Screen.height - edgeSize) e.y += 1f;
            transform.position += e * panSpeed * zoomFactor * Time.unscaledDeltaTime;
        }

        // плавный зум: колесо задаёт цель, камера мягко доезжает; поверх UI не работает
        float maxFit = float.MaxValue;
        if (WorldGrid.Width > 0)
            maxFit = Mathf.Min(WorldGrid.Height * 0.5f, (WorldGrid.Width * 0.5f) / cam.aspect);
        float maxNow = Mathf.Min(maxZoom, maxFit);

        float scroll = Input.mouseScrollDelta.y;
        if (scroll != 0f && !GameUI.BlockInput)
            targetSize = Mathf.Clamp(targetSize - scroll * zoomSpeed, minZoom, maxNow);
        targetSize = Mathf.Clamp(targetSize, minZoom, maxNow);

        float old = cam.orthographicSize;
        float next = Mathf.Lerp(old, targetSize, 1f - Mathf.Pow(0.001f, Time.unscaledDeltaTime));
        if (Mathf.Abs(next - old) > 0.0001f)
        {
            // держим точку под курсором на месте
            Vector3 before = cam.ScreenToWorldPoint(Input.mousePosition);
            cam.orthographicSize = next;
            Vector3 after = cam.ScreenToWorldPoint(Input.mousePosition);
            transform.position += before - after;
        }

        if (clampToMap) ClampToBounds();
    }

    private bool MouseInGameView()
    {
        Vector3 m = Input.mousePosition;
        return m.x >= 0 && m.x <= Screen.width && m.y >= 0 && m.y <= Screen.height;
    }

    private void ClampToBounds()
    {
        if (WorldGrid.Width == 0) return;

        float halfH = cam.orthographicSize;
        float halfW = halfH * cam.aspect;

        float minX = -0.5f - margin + halfW;
        float maxX = WorldGrid.Width - 0.5f + margin - halfW;
        float minY = -0.5f - margin + halfH;
        float maxY = WorldGrid.Height - 0.5f + margin - halfH;

        Vector3 p = transform.position;
        p.x = minX <= maxX ? Mathf.Clamp(p.x, minX, maxX) : (WorldGrid.Width - 1f) * 0.5f;
        p.y = minY <= maxY ? Mathf.Clamp(p.y, minY, maxY) : (WorldGrid.Height - 1f) * 0.5f;
        transform.position = p;
    }
}