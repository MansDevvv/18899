using System.Collections.Generic;
using UnityEngine;

public static class WorldGrid
{
    public static int Width { get; private set; }
    public static int Height { get; private set; }

    static readonly HashSet<Vector2Int> blocked = new HashSet<Vector2Int>();
    static readonly Dictionary<Vector2Int, ResourceNode> resources = new Dictionary<Vector2Int, ResourceNode>();
    static readonly Dictionary<Vector2Int, ResourceDrop> drops = new Dictionary<Vector2Int, ResourceDrop>();
    static readonly HashSet<Vector2Int> walls = new HashSet<Vector2Int>();
    static readonly Dictionary<Vector2Int, WallAutoTile> wallObjs = new Dictionary<Vector2Int, WallAutoTile>();
    static readonly Dictionary<Vector2Int, bool> beds = new Dictionary<Vector2Int, bool>();
    static readonly HashSet<Vector2Int> occupiedBeds = new HashSet<Vector2Int>();
    static readonly HashSet<Vector2Int> desks = new HashSet<Vector2Int>();
    static readonly Dictionary<Vector2Int, Door> doors = new Dictionary<Vector2Int, Door>();
    static readonly Dictionary<Vector2Int, GameObject> furnObjs = new Dictionary<Vector2Int, GameObject>();
    static readonly HashSet<Vector2Int> indoor = new HashSet<Vector2Int>();
    public static System.Action OnRoomsChanged;
    public static IEnumerable<Vector2Int> IndoorCells() => indoor;
    static readonly List<StockpileZone> zones = new List<StockpileZone>();

    public static void SetSize(int w, int h) { Width = w; Height = h; }
    public static bool InBounds(Vector2Int c) => c.x >= 0 && c.y >= 0 && c.x < Width && c.y < Height;

    // ===== блокировки =====
    public static bool IsBlocked(Vector2Int c) => blocked.Contains(c);
    public static void SetBlocked(Vector2Int c) => blocked.Add(c);
    public static void SetFree(Vector2Int c) => blocked.Remove(c);

    public static bool IsPathPassable(Vector2Int c) =>
        InBounds(c) && (!blocked.Contains(c) || doors.ContainsKey(c));

    // ===== ресурсы =====
    public static ResourceNode GetResource(Vector2Int c) => resources.TryGetValue(c, out var r) ? r : null;
    public static void AddResource(ResourceNode r) => resources[r.Coord] = r;
    public static void RemoveResource(Vector2Int c) => resources.Remove(c);

    // ===== дропы =====
    public static ResourceDrop GetDrop(Vector2Int c) => drops.TryGetValue(c, out var d) ? d : null;
    public static void AddDrop(ResourceDrop d) => drops[d.Coord] = d;
    public static void RemoveDrop(Vector2Int c) => drops.Remove(c);
    public static IEnumerable<ResourceDrop> AllDrops() => drops.Values;

    // ===== зоны (склад/мусор/огород) =====
    public static List<StockpileZone> Zones => zones;
    public static StockpileZone ZoneAt(Vector2Int c) { foreach (var z in zones) if (z.Contains(c)) return z; return null; }
    public static void AddZone(StockpileZone z) => zones.Add(z);
    public static void RemoveZone(StockpileZone z) => zones.Remove(z);

    public static bool IsStockpile(Vector2Int c) { var z = ZoneAt(c); return z != null && z.type == ZoneType.Stockpile; }
    public static bool HasStockpile { get { foreach (var z in zones) if (z.type == ZoneType.Stockpile) return true; return false; } }

    public static void SetStockpile(HashSet<Vector2Int> zone)
    {
        if (zone.Count == 0) return;
        int x0 = int.MaxValue, y0 = int.MaxValue, x1 = int.MinValue, y1 = int.MinValue;
        foreach (var c in zone)
        {
            x0 = Mathf.Min(x0, c.x); y0 = Mathf.Min(y0, c.y);
            x1 = Mathf.Max(x1, c.x + 1); y1 = Mathf.Max(y1, c.y + 1);
        }
        zones.Add(new StockpileZone(ZoneType.Stockpile, new RectInt(x0, y0, x1 - x0, y1 - y0)));
    }

    public static Vector2Int NearestStockpile(Vector2Int from) => NearestZoneCell(from, z => z.type == ZoneType.Stockpile);
    public static Vector2Int NearestStockpileAccepting(Vector2Int from, ResourceType t, bool poison)
        => NearestZoneCell(from, z => z.type == ZoneType.Stockpile && z.Accepts(t, poison));

    static Vector2Int NearestZoneCell(Vector2Int from, System.Func<StockpileZone, bool> pred)
    {
        Vector2Int best = new Vector2Int(-1000, -1000);
        float bd = float.MaxValue;
        foreach (var z in zones)
        {
            if (!pred(z)) continue;
            for (int x = z.rect.xMin; x < z.rect.xMax; x++)
                for (int y = z.rect.yMin; y < z.rect.yMax; y++)
                {
                    var c = new Vector2Int(x, y);
                    float d = (c - from).sqrMagnitude;
                    if (d < bd) { bd = d; best = c; }
                }
        }
        return best;
    }

    // ===== стены =====
    public static bool IsWall(Vector2Int c) => walls.Contains(c);
    public static WallAutoTile GetWall(Vector2Int c) => wallObjs.TryGetValue(c, out var w) ? w : null;
    public static void RegisterWall(Vector2Int c, WallAutoTile w)
    {
        walls.Add(c);
        if (w != null) wallObjs[c] = w;
        RefreshWall(c);
        RefreshWall(c + new Vector2Int(1, 0));
        RefreshWall(c + new Vector2Int(-1, 0));
        RefreshWall(c + new Vector2Int(0, 1));
        RefreshWall(c + new Vector2Int(0, -1));
        RecomputeRooms();
    }
    public static void RemoveWall(Vector2Int c)
    {
        walls.Remove(c);
        wallObjs.Remove(c);
        blocked.Remove(c);
        RefreshWall(c + new Vector2Int(1, 0));
        RefreshWall(c + new Vector2Int(-1, 0));
        RefreshWall(c + new Vector2Int(0, 1));
        RefreshWall(c + new Vector2Int(0, -1));
        RecomputeRooms();
    }
    public static void RefreshWall(Vector2Int c)
    {
        if (wallObjs.TryGetValue(c, out var w) && w != null) w.Refresh();
        var d = GetDoor(c);
        if (d != null) d.Refresh();
    }

    // ===== кровати =====
    public static void AddBed(Vector2Int c, bool soldier) => beds[c] = soldier;
    public static void RemoveBed(Vector2Int c) { beds.Remove(c); occupiedBeds.Remove(c); }
    public static bool IsBed(Vector2Int c) => beds.ContainsKey(c);
    public static bool IsSoldierBed(Vector2Int c) => beds.TryGetValue(c, out var s) && s;
    public static void OccupyBed(Vector2Int c, bool on) { if (on) occupiedBeds.Add(c); else occupiedBeds.Remove(c); }
    public static Vector2Int FindFreeBed(bool soldier)
    {
        foreach (var kv in beds)
            if (kv.Value == soldier && !occupiedBeds.Contains(kv.Key)) return kv.Key;
        return new Vector2Int(-1000, -1000);
    }

    // ===== столы =====
    public static void AddDesk(Vector2Int c) => desks.Add(c);
    public static void RemoveDesk(Vector2Int c) => desks.Remove(c);
    public static bool IsDesk(Vector2Int c) => desks.Contains(c);
    public static Vector2Int NearestDesk(Vector2Int from)
    {
        Vector2Int best = new Vector2Int(-1000, -1000);
        float bd = float.MaxValue;
        foreach (var d in desks) { float q = (d - from).sqrMagnitude; if (q < bd) { bd = q; best = d; } }
        return best;
    }

    // ===== двери =====
    public static void AddDoor(Vector2Int c, Door d) => doors[c] = d;
    public static void RemoveDoor(Vector2Int c) => doors.Remove(c);
    public static bool IsDoor(Vector2Int c) => doors.ContainsKey(c);
    public static Door GetDoor(Vector2Int c) => doors.TryGetValue(c, out var d) ? d : null;

    // ===== объекты мебели =====
    public static void SetFurnObj(Vector2Int c, GameObject go) => furnObjs[c] = go;
    public static GameObject GetFurnObj(Vector2Int c) => furnObjs.TryGetValue(c, out var g) ? g : null;
    public static void RemoveFurnObj(Vector2Int c) => furnObjs.Remove(c);

    // ===== комнаты =====
    public static bool IsIndoor(Vector2Int c) => indoor.Contains(c);

    public static void RecomputeRooms()
    {
        indoor.Clear();
        if (Width == 0) return;
        var visited = new HashSet<Vector2Int>();
        var q = new Queue<Vector2Int>();

        void Seed(Vector2Int c) { if (InBounds(c) && !blocked.Contains(c) && visited.Add(c)) q.Enqueue(c); }
        for (int x = 0; x < Width; x++) { Seed(new Vector2Int(x, 0)); Seed(new Vector2Int(x, Height - 1)); }
        for (int y = 0; y < Height; y++) { Seed(new Vector2Int(0, y)); Seed(new Vector2Int(Width - 1, y)); }

        while (q.Count > 0)
        {
            var c = q.Dequeue();
            foreach (var n in N4(c))
                if (InBounds(n) && !blocked.Contains(n) && visited.Add(n)) q.Enqueue(n);
        }

        for (int x = 0; x < Width; x++)
            for (int y = 0; y < Height; y++)
            {
                var c = new Vector2Int(x, y);
                            if (!blocked.Contains(c) && !visited.Contains(c)) indoor.Add(c);
            }
            OnRoomsChanged?.Invoke();
    }

    static Vector2Int[] N4(Vector2Int c) => new[]
    {
        new Vector2Int(c.x + 1, c.y),
        new Vector2Int(c.x - 1, c.y),
        new Vector2Int(c.x, c.y + 1),
        new Vector2Int(c.x, c.y - 1),
    };

    // ===== очистка =====
    public static void ClearAll()
    {
        blocked.Clear();
        resources.Clear();
        drops.Clear();
        walls.Clear();
        wallObjs.Clear();
        beds.Clear();
        occupiedBeds.Clear();
        desks.Clear();
        doors.Clear();
        furnObjs.Clear();
        indoor.Clear();
        zones.Clear();
    }

    public static Vector2Int MouseCoord()
    {
        Vector3 p = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        return new Vector2Int(Mathf.RoundToInt(p.x), Mathf.RoundToInt(p.y));
    }
}