using UnityEngine;

public class StockpileMode : MonoBehaviour
{
    public static bool IsActive { get; private set; }
    public static ZoneType CurrentType { get; private set; }

    bool dragging;
    Vector2Int start, cur;
    static Texture2D px;

    public static void Begin(ZoneType t) { CurrentType = t; IsActive = true; BuildMode.Deactivate(); }
    public static void Deactivate() { IsActive = false; }

    void Update()
    {
        if (!IsActive) return;
        if (Input.GetKeyDown(KeyCode.Escape) || Input.GetMouseButtonDown(1)) { IsActive = false; return; }
        if (GameUI.BlockInput) return;

        if (Input.GetMouseButtonDown(0)) { dragging = true; start = WorldGrid.MouseCoord(); cur = start; }
        if (dragging) cur = WorldGrid.MouseCoord();
        if (dragging && Input.GetMouseButtonUp(0))
        {
            dragging = false;
            int x0 = Mathf.Min(start.x, cur.x), y0 = Mathf.Min(start.y, cur.y);
            int x1 = Mathf.Max(start.x, cur.x) + 1, y1 = Mathf.Max(start.y, cur.y) + 1;
            var r = new RectInt(x0, y0, x1 - x0, y1 - y0);
            WorldGrid.AddZone(new StockpileZone(CurrentType, r));
            IsActive = false;
        }
    }

    void OnGUI()
    {
        if (!IsActive || !dragging) return;
        Vector3 a = Camera.main.WorldToScreenPoint(new Vector3(Mathf.Min(start.x, cur.x) - 0.5f, Mathf.Min(start.y, cur.y) - 0.5f, 0));
        Vector3 b = Camera.main.WorldToScreenPoint(new Vector3(Mathf.Max(start.x, cur.x) + 0.5f, Mathf.Max(start.y, cur.y) + 0.5f, 0));
        Rect r = new Rect(a.x, Screen.height - b.y, b.x - a.x, b.y - a.y);
        if (px == null) { px = new Texture2D(1, 1); px.SetPixel(0, 0, new Color(0.3f, 0.8f, 1f, 0.4f)); px.Apply(); }
        GUI.DrawTexture(r, px);
    }
}