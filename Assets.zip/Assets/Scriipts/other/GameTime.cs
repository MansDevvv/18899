using UnityEngine;
public static class GameTime
{
    public static float dayLength = 1560f; // пересчитается DayNightCycle из минут
    public static float time;
    public static int Day => Mathf.FloorToInt(time / dayLength) + 1;
    public static float DayPart => (time % dayLength) / dayLength;
    public static void Tick(float dt) { time += dt; }
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void ResetTime() { time = 0f; }
}