using System.Collections.Generic;
using UnityEngine;
public class Colonist : MonoBehaviour
{
public enum SocialClass { Worker, Bourgeoisie, Soldier }
public SocialClass socialClass = SocialClass.Worker;
public bool isGeneral;
public static readonly List<Colonist> all = new List<Colonist>();
[Header("Работа")]
public float harvestTime = 3f;
public GameObject woodDropPrefab;
public GameObject rockDropPrefab;
public GameObject foodDropPrefab;
[Header("Спрайты направлений")]
public Sprite spriteFront;
public Sprite spriteBack;
public Sprite spriteRight;
public Sprite spriteLeft;
[Header("Спрайты рабочего")]
public Sprite workerFront, workerBack, workerRight, workerLeft;
[Header("Спрайты буржуа")]
public Sprite bourgFront, bourgBack, bourgRight, bourgLeft;
[Header("Спрайты солдата")]
public Sprite soldierFront, soldierBack, soldierRight, soldierLeft;
[Header("Потребности")]
public float energy = 100f;
public float food = 100f;
public float fun = 100f;
public float health = 100f;
public float stress = 0f;
public float sleepiness = 0f;
public float adrenaline = 0f;
[HideInInspector] public bool selected;
[HideInInspector] public string pname;
[HideInInspector] public string backstory;
public enum Trait { Lazy, Hardworking, Cheerful, Panicker, Nervous, Tough, Wimp, Gourmand, Workaholic, Ascetic }
public Trait trait;
public enum Sickness { None, Cold, Flu, Plague }
public Sickness sick = Sickness.None;
public bool injured;
public bool depressed;
public bool giveUp;
public Dictionary<SkillType, Skill> skills = new Dictionary<SkillType, Skill>();
public float stamina;
public struct Thought { public string text; public float value; public float daysLeft; }
public List<Thought> thoughts = new List<Thought>();
PawnMovement movement;
SpriteRenderer sr;
GameObject carriedObj;
List<Vector2Int> path = new List<Vector2Int>();
int pathIndex;
Vector2Int pathTarget;
enum State { Idle, Moving, Working, Sleeping, Eating, Breakdown, Talking, Exhausted }
State state = State.Idle;
enum BreakKind { Tantrum, Panic, Stupor, Binge, GiveUp, Strike }
BreakKind breakKind;
Job job;
bool hasJob;
float workTimer;
float workTotal;
float myBuildRate;
ResourceType fetchType;
int fetchCost;
float restTimer;
float sleptTime;
bool sleepWasTired;
bool sleptOutside = true;
float breakdownTimer;
float panicTimer;
float giveUpTimer;
float sickDaysLeft;
float sickCooldown;
float lowMoodDays;
float poisonTimer;
bool carrying;
ResourceType carryingType;
int carryingAmount;
bool carryingRefund;
bool carryingPoison;
bool goingToEat;
Vector2Int myBed;
bool hasBed;
bool goingToSleep;
bool buildFetch;      // идёт брать со склада
bool buildFetchDrop;  // идёт брать дроп с земли
bool buildHasMat;     // несёт материал к чертежу
Vector2Int fetchDropCoord;
bool goingToDeliver;
BerryBush targetBush;
bool goingToBerry;
bool harvestingBerry;
float boostTimer;
float yellCd;
float patrolCd;
float trainCd;
Colonist socialPartner;
bool goingToTalk;
float talkTimer;
Vector3 lastPos;
Vector2 lastDir = new Vector2(0, -1);
static readonly string[] Names = { "Иван", "Марья", "Борис", "Ольга", "Саныч", "Гриша", "Нюра", "Витёк", "Пётр", "Зина", "Кузьма", "Лиза", "Матвей", "Ася", "Тимофей", "Вера", "Егор", "Нина", "Платон", "Зоя" };
public string ClassRu() => socialClass == SocialClass.Worker ? "рабочий" : socialClass == SocialClass.Bourgeoisie ? (isGeneral ? "генерал" : "буржуа") : "солдат";
public bool IsWorkingBuild => hasJob && state == State.Working && job.type == JobType.Build;
public bool IsWorkingHarvest => state == State.Working && (harvestingBerry || (hasJob && job.type == JobType.Harvest));
public float WorkProgress => hasJob && job.type == JobType.Build ? BuildMode.GetProgress(job.coord) : (workTotal > 0f ? Mathf.Clamp01(1f - workTimer / workTotal) : 0f);
public Vector2Int JobCoord => job.coord;
public Vector2Int HarvestCoord => harvestingBerry && targetBush != null ? targetBush.Coord : job.coord;
public string TraitRu()
{
switch (trait)
{
case Trait.Lazy: return "ленивый";
case Trait.Hardworking: return "усердный";
case Trait.Cheerful: return "радостный";
case Trait.Panicker: return "паникёр";
case Trait.Nervous: return "нервный";
case Trait.Tough: return "стойкий";
case Trait.Wimp: return "слабак";
case Trait.Gourmand: return "обжора";
case Trait.Workaholic: return "трудоголик";
default: return "аскет";
}
}
float TraitWorkMul => trait == Trait.Lazy ? 1.5f : trait == Trait.Hardworking ? 0.75f : trait == Trait.Workaholic ? 0.85f : 1f;
float TraitStressGain => trait == Trait.Tough ? 0.5f : trait == Trait.Nervous ? 1.6f : trait == Trait.Wimp ? 1.4f : trait == Trait.Hardworking ? 1.3f : trait == Trait.Panicker ? 1.2f : trait == Trait.Cheerful ? 0.8f : 1f;
float TraitFunDrain => trait == Trait.Cheerful ? 0.6f : trait == Trait.Ascetic ? 0.5f : 1f;
float TraitHungerDrain => trait == Trait.Gourmand ? 1.4f : 1f;
float TraitMoodOffset => trait == Trait.Cheerful ? 10f : trait == Trait.Ascetic ? 5f : trait == Trait.Nervous ? -5f : 0f;
void InitSkills()
{
skills.Clear();
foreach (SkillType t in System.Enum.GetValues(typeof(SkillType))) skills[t] = new Skill { level = Skills.RollLevel() };
skills[SkillType.Intellect].level = Skills.RollIntellect();
stamina = Skills.MaxStamina(skills[SkillType.Endurance].level);
backstory = MakeBackstory();
}
string MakeBackstory()
{
SkillType top1 = SkillType.Construction, top2 = SkillType.Melee;
int l1 = -1, l2 = -1;
foreach (var kv in skills)
{
if (kv.Key == SkillType.Intellect) continue;
if (kv.Value.level > l1) { l2 = l1; top2 = top1; l1 = kv.Value.level; top1 = kv.Key; }
else if (kv.Value.level > l2) { l2 = kv.Value.level; top2 = kv.Key; }
}
int intel = skills[SkillType.Intellect].level;
string cls = socialClass == SocialClass.Bourgeoisie ? "Из богатой семьи, умеет считать деньги и командовать." :
socialClass == SocialClass.Soldier ? "Прошёл службу, держит строй." : "С детства трудится руками.";
return $"{cls} {Skills.StoryFor(top1, l1)}. {Skills.StoryFor(top2, l2)}. Ум {intel} (x{Skills.IntellectXpMult(intel):0.0} к прокачке).";
}
public void GainSkill(SkillType t, float amount)
{
Skill s = skills[t];
if (s.level >= Skills.MaxLevel) return;
if (Skills.IntellectBoosts(t)) amount *= Skills.IntellectXpMult(skills[SkillType.Intellect].level);
s.xp += amount;
while (s.xp >= 100f && s.level < Skills.MaxLevel)
{
s.xp -= 100f; s.level++;
Notifier.Add($"{pname}: навык \"{Skills.Ru(t)}\" теперь {s.level}!");
if (t == SkillType.Endurance) stamina = Mathf.Min(Skills.MaxStamina(s.level), stamina + 60f);
}
}
public float MaxStaminaNow => Skills.MaxStamina(skills[SkillType.Endurance].level);
bool CanBuildWall(BuildMode.WallType wt) => wt == BuildMode.WallType.Wood || Skills.CanBuildStone(skills[SkillType.Construction].level);
float BuildTimeNow(BuildMode.WallType wt)
{
int lvl = skills[SkillType.Construction].level;
return wt == BuildMode.WallType.Wood ? Skills.BuildTimeWood(lvl) : Skills.BuildTimeStone(lvl);
}
bool BankHas(ResourceType t, int n) => t == ResourceType.Wood ? Storage.wood >= n : Storage.stone >= n;
void BankTake(ResourceType t, int n) { if (t == ResourceType.Wood) Storage.wood -= n; else Storage.stone -= n; }
void ResetBuildFlags() { buildFetch = false; buildFetchDrop = false; buildHasMat = false; }
void AbandonBuild()
{
if (isBuilderNow) BuildMode.RemoveBuilder(job.coord);
isBuilderNow = false;
ResetBuildFlags();
}
bool isBuilderNow;
// ===== физическая модель: чертёж "готов", если ресурс лежит дропом ИЛИ есть в банке =====
bool BuildReady(Vector2Int c)
{
BuildMode.BlueprintCost(c, out var rt, out var cost);
if (BankHas(rt, cost)) return true;
return NearestDropOf(rt) != null;
}
bool AcceptJob(Job j) =>
j.type != JobType.Build ||
(CanBuildWall(BuildMode.GetBlueprintType(j.coord)) && BuildReady(j.coord));
ResourceDrop NearestDropOf(ResourceType t)
{
ResourceDrop best = null; float bd = float.MaxValue;
foreach (var d in WorldGrid.AllDrops())
{
if (d == null || d.type != t) continue;
float q = (d.Coord - CurrentCoord()).sqrMagnitude;
if (q < bd) { bd = q; best = d; }
}
return best;
}
void ShowCarried()
{
HideCarried();
GameObject prefab = carryingType == ResourceType.Wood ? DropFactory.woodPrefab : carryingType == ResourceType.Stone ? DropFactory.rockPrefab : DropFactory.foodPrefab;
if (prefab == null) return;
var pr = prefab.GetComponent<SpriteRenderer>();
if (pr == null || pr.sprite == null) return;
carriedObj = new GameObject("Carried");
carriedObj.transform.SetParent(transform);
carriedObj.transform.localPosition = new Vector3(0f, 0.45f, 0f);
carriedObj.transform.localScale = new Vector3(0.4f, 0.4f, 1f);
var r = carriedObj.AddComponent<SpriteRenderer>();
r.sprite = pr.sprite;
r.sortingOrder = 8;
}
void HideCarried()
{
if (carriedObj != null) { Object.Destroy(carriedObj); carriedObj = null; }
}
public float Mood
{
get
{
float baseM = energy * 0.25f + food * 0.25f + fun * 0.25f + health * 0.25f;
float sum = 0;
foreach (Thought t in thoughts) sum += t.value;
sum = Mathf.Clamp(sum, -40f, 40f);
return Mathf.Clamp(baseM + sum + TraitMoodOffset, 0f, 100f);
}
}
public string MoodText() => Mood > 70 ? "доволен" : Mood > 40 ? "норм" : Mood > 20 ? "плохо" : "ужасно";
public void AddThought(string text, float value, float days)
{
for (int i = 0; i < thoughts.Count; i++)
if (thoughts[i].text == text)
{
Thought t = thoughts[i]; t.value = value; t.daysLeft = days; thoughts[i] = t; return;
}
thoughts.Add(new Thought { text = text, value = value, daysLeft = days });
}
public string SickRu() => sick == Sickness.Cold ? "простуда" : sick == Sickness.Flu ? "грипп" : sick == Sickness.Plague ? "чума" : "";
public string StatusText()
{
switch (state)
{
case State.Sleeping: return sleepWasTired ? "спит" : "просто лежит";
case State.Eating: return "ест";
case State.Exhausted: return "выдохся, отдышаться";
case State.Talking: return socialPartner != null ? "разговаривает с " + socialPartner.pname : "разговаривает";
case State.Breakdown: return BreakRu();
case State.Working: return harvestingBerry ? "собирает ягоды" : "работает: " + JobRu();
case State.Moving: return carrying ? "несёт на склад" : hasJob ? (buildFetch || buildFetchDrop ? "идёт за материалом" : buildHasMat ? "несёт материал к чертежу" : "идёт на задание") : goingToEat ? "идёт есть" : goingToBerry ? "идёт собирать ягоды" : goingToTalk ? "идёт поболтать" : goingToSleep ? "идёт спать" : socialClass == SocialClass.Soldier ? "патрулирует" : "гуляет";
default: return giveUp ? "бастует" : socialClass == SocialClass.Bourgeoisie ? "изучает технологии" : "бездельничает";
}
}
string BreakRu()
{
switch (breakKind)
{
case BreakKind.Tantrum: return "ИСТЕРИКА! ломает всё";
case BreakKind.Panic: return "ПАНИКА!!! мечется";
case BreakKind.Binge: return "обжирается на складе";
case BreakKind.GiveUp: return "опустил руки";
case BreakKind.Strike: return "ЗАБАСТОВКА!";
default: return "ступор, лежит";
}
}
string JobRu() => job.type == JobType.Build ? "стройка" : job.type == JobType.Harvest ? "добыча" : "переноска";
public string JobInfo() => hasJob ? $"{JobRu()} -> ({job.coord.x},{job.coord.y})" : socialClass == SocialClass.Bourgeoisie ? "исследование" : "задачи нет";
public string NextWant()
{
if (poisonTimer > 0f) return "хочет: не блевануть";
if (sleepiness > 70f) return "хочет: поспать";
if (stamina <= 1f) return "хочет: отдышаться";
if (food < 30f) return "хочет: поесть";
if (energy < 30f) return "хочет: отдохнуть";
if (sick != Sickness.None) return "хочет: отлежаться";
if (stress >= 80f) return "хочет: не словить срыв...";
if (fun < 40f) return "хочет: погулять";
return "хочет: работать";
}
public string FlagsText()
{
string s = "";
if (sick != Sickness.None) s += "БОЛЕН(" + SickRu() + ") ";
if (injured) s += "ТРАВМИРОВАН ";
if (depressed) s += "ДЕПРЕССИЯ ";
if (poisonTimer > 0f) s += "ОТРАВИЛСЯ ";
if (sleepiness > 70f) s += "НЕ ВЫСПАЛСЯ ";
if (adrenaline > 20f) s += "АДРЕНАЛИН ";
if (boostTimer > 0f) s += "ПОГНАЛ НАЧАЛЬНИК ";
return s == "" ? "здоров" : s;
}
void Awake()
{
movement = GetComponent<PawnMovement>();
sr = GetComponent<SpriteRenderer>();
trait = (Trait)Random.Range(0, 10);
pname = Names[Random.Range(0, Names.Length)];
DropFactory.woodPrefab = woodDropPrefab;
DropFactory.rockPrefab = rockDropPrefab;
DropFactory.foodPrefab = foodDropPrefab;
lastPos = transform.position;
InitSkills();
RefreshSprites();
if (GetComponent<SunShadow>() == null) gameObject.AddComponent<SunShadow>();
all.Add(this);
}
void OnDestroy() { all.Remove(this); }
public void SetClass(SocialClass c)
{
if (socialClass == c) return;
socialClass = c;
if (hasJob) { JobQueue.Requeue(job); hasJob = false; AbandonBuild(); }
if (c != SocialClass.Bourgeoisie) isGeneral = false;
RefreshSprites();
Notifier.Add($"{pname}: теперь {ClassRu()}");
}
public void ToggleGeneral()
{
isGeneral = !isGeneral;
if (isGeneral) foreach (var o in all) if (o != this) o.isGeneral = false;
Notifier.Add(isGeneral ? $"{pname} назначен(а) генералом!" : $"{pname} больше не генерал");
}
public void RefreshSprites()
{
if (socialClass == SocialClass.Bourgeoisie && bourgFront != null) { spriteFront = bourgFront; spriteBack = bourgBack; spriteRight = bourgRight; spriteLeft = bourgLeft; }
else if (socialClass == SocialClass.Soldier && soldierFront != null) { spriteFront = soldierFront; spriteBack = soldierBack; spriteRight = soldierRight; spriteLeft = soldierLeft; }
else if (workerFront != null) { spriteFront = workerFront; spriteBack = workerBack; spriteRight = workerRight; spriteLeft = workerLeft; }
}
void LateUpdate()
{
bool lying = (state == State.Sleeping && !hasBed) || (state == State.Breakdown && breakKind == BreakKind.Stupor) || state == State.Exhausted;
transform.rotation = lying ? Quaternion.Euler(0f, 0f, 90f) : Quaternion.identity;
UpdateFacing();
}
void UpdateFacing()
{
if (sr == null) return;
Vector2 dir;
if (state == State.Talking && socialPartner != null) dir = socialPartner.transform.position - transform.position;
else if (state == State.Moving || state == State.Working)
{
Vector3 delta = transform.position - lastPos;
if (delta.sqrMagnitude > 0.00001f) lastDir = new Vector2(delta.x, delta.y).normalized;
dir = lastDir;
}
else dir = new Vector2(0, -1);
lastPos = transform.position;
if (Mathf.Abs(dir.x) > Mathf.Abs(dir.y)) SetSprite(dir.x > 0 ? spriteRight : spriteLeft);
else SetSprite(dir.y > 0 ? spriteBack : spriteFront);
}
void SetSprite(Sprite s) { if (s != null && sr.sprite != s) sr.sprite = s; }
void Update()
{
TickNeeds(Time.deltaTime);
if (health <= 0f) { Die(); return; }
switch (state)
{
case State.Working:
if (isBuilderNow && hasJob && job.type == JobType.Build)
{
if (!BuildMode.blueprints.ContainsKey(job.coord)) { AbandonBuild(); hasJob = false; state = State.Idle; break; }
float p = BuildMode.GetProgress(job.coord) + myBuildRate * Time.deltaTime;
BuildMode.SetProgress(job.coord, p);
if (p >= 1f) FinishWork();
}
else { workTimer -= Time.deltaTime; if (workTimer <= 0f) FinishWork(); }
break;
case State.Sleeping:
restTimer -= Time.deltaTime;
sleptTime += Time.deltaTime;
bool wake = sleepWasTired ? (sleptTime > 1f && sleepiness <= 5f) : restTimer <= 0f;
if (wake)
{
state = State.Idle;
if (hasBed) { if (WorldGrid.IsIndoor(myBed)) AddThought("спал в тёплой комнате", 3f, 1f); WorldGrid.OccupyBed(myBed, false); hasBed = false; }
else if (sleptOutside) AddThought("спал на земле", -4f, 1f);
}
break;
case State.Exhausted:
if (stamina >= MaxStaminaNow * 0.5f) state = State.Idle;
break;
case State.Eating:
workTimer -= Time.deltaTime;
if (workTimer <= 0f)
{
if (Storage.food >= 2) { Storage.food -= 2; food = Mathf.Min(100f, food + 40f); AddThought("поел ягод", 2f, 0.3f); }
else if (Storage.poisonFood >= 1)
{
Storage.poisonFood -= 1; food = Mathf.Min(100f, food + 20f);
if (Random.value < 0.45f) { poisonTimer = 8f; AddThought("тошнит от ядовитых ягод", -6f, 1f); stress = Mathf.Min(100f, stress + 10f); Notifier.Add(pname + " отравился(ась) ядовитыми ягодами!"); }
}
state = State.Idle;
}
break;
case State.Talking:
talkTimer -= Time.deltaTime;
if (talkTimer <= 0f) FinishTalk();
break;
case State.Breakdown:
UpdateBreakdown();
break;
case State.Moving:
StepPath();
if (pathIndex >= path.Count && !movement.IsMoving)
{
if (goingToSleep) { goingToSleep = false; StartSleep(); }
else if (goingToBerry) { goingToBerry = false; StartBerry(); }
else if (goingToDeliver) Deposit();
else if (hasJob) ArriveAtJob();
else if (goingToEat) { goingToEat = false; state = State.Eating; workTimer = 1.5f; }
else if (goingToTalk) { goingToTalk = false; TryStartTalk(); }
else state = State.Idle;
}
break;
case State.Idle:
Think();
break;
}
}
void TickNeeds(float dt)
{
float day = GameTime.dayLength;
food -= (100f / (3f * day)) * TraitHungerDrain * dt;
if (poisonTimer > 0f) { poisonTimer -= dt; fun -= 1f * dt; health -= 0.3f * dt; }
// сонливость по времени суток
if (state != State.Sleeping)
{
string ph = DayNightCycle.PhaseRu;
float gain = ph == "ночь" ? 1.2f : ph == "вечер" ? 1.0f : ph == "утро" ? 0.15f : 0.25f;
if ((state == State.Working || state == State.Moving) && (ph == "ночь" || ph == "вечер")) gain *= 1.6f;
sleepiness += gain * dt;
}
else sleepiness -= (DayNightCycle.PhaseRu == "день" ? 2.5f : 4f) * dt;
if (adrenaline > 0f)
{
adrenaline = Mathf.Max(0f, adrenaline - (100f / 60f) * dt);
sleepiness -= (adrenaline / 100f) * 1.5f * dt;
}
sleepiness = Mathf.Clamp(sleepiness, 0f, 100f);
if (boostTimer > 0f) boostTimer -= dt;
if (socialClass == SocialClass.Bourgeoisie && state != State.Sleeping && !depressed)
{
Vector2Int me = CurrentCoord();
bool atDesk = WorldGrid.IsDesk(me) || WorldGrid.IsDesk(me + new Vector2Int(1, 0)) || WorldGrid.IsDesk(me + new Vector2Int(-1, 0)) || WorldGrid.IsDesk(me + new Vector2Int(0, 1)) || WorldGrid.IsDesk(me + new Vector2Int(0, -1));
Storage.research += (atDesk ? 0.5f : 0.15f) * dt;
}
if (sleepiness >= 100f && adrenaline < 50f && state != State.Sleeping && state != State.Breakdown)
{
LeaveTalk();
if (hasJob) { JobQueue.Requeue(job); hasJob = false; AbandonBuild(); }
AddThought("вырубился от недосыпа", -3f, 0.5f);
StartSleep();
}
if (state == State.Moving) stamina -= 1f * dt;
else if (state == State.Working)
{
bool hard = harvestingBerry || (hasJob && job.type == JobType.Harvest);
stamina -= (hard ? 2f : 0.5f) * dt;
}
else stamina += (MaxStaminaNow / Skills.StaminaRegenTime) * dt;
stamina = Mathf.Clamp(stamina, 0f, MaxStaminaNow);
if (stamina <= 0f && state != State.Exhausted && state != State.Sleeping)
{
if (hasJob) { JobQueue.Requeue(job); hasJob = false; AbandonBuild(); }
state = State.Exhausted;
GainSkill(SkillType.Endurance, 1f);
Notifier.Add(pname + " выдохся(ась) и отдыхает");
}
if (state == State.Working) { energy -= 1.5f * dt; fun -= 1f * TraitFunDrain * dt; stress += 1f * TraitStressGain * dt; }
else if (state == State.Moving) { energy -= 0.4f * dt; fun -= 0.2f * dt; stress += 0.15f * dt; }
else if (state == State.Sleeping) { energy += 8f * dt; fun += 2f * dt; stress -= 3f * dt; }
else if (state == State.Talking) { energy -= 0.2f * dt; fun += 1.5f * dt; stress -= 1f * dt; }
else if (state == State.Breakdown) { stress -= 5f * dt; }
else
{
energy += 3f * dt;
fun += (trait == Trait.Cheerful ? 2f : 1f) * dt;
stress -= 1f * dt;
if (trait == Trait.Workaholic) stress += 1.5f * dt;
}
if (food <= 0f) { health -= 2f * dt; AddThought("голодает", -8f, 0.5f); }
if (sick == Sickness.Plague) health -= 0.8f * dt;
else if (sick == Sickness.Flu) health -= 0.25f * dt;
else if (sick == Sickness.Cold) health -= 0.08f * dt;
if (food > 40f && energy > 30f && sick == Sickness.None) health += 1.2f * dt;
if (injured && health > 75f) { injured = false; AddThought("рана зажила", 2f, 1f); }
sickCooldown -= dt / day;
if (sick == Sickness.None && sickCooldown <= 0f)
{
float risk = 0.1f;
if (energy < 25f) risk += 1f;
if (food < 25f) risk += 1f;
if (stress > 70f) risk += 0.5f;
if (injured) risk += 0.5f;
if (sleepiness > 80f) risk += 1f;
if (sleptOutside) risk += 0.5f;
if (DayNightCycle.PhaseRu == "ночь" && state != State.Sleeping) risk += 0.5f;
foreach (Colonist o in all)
{
if (o == this || o.sick == Sickness.None) continue;
if ((o.CurrentCoord() - CurrentCoord()).sqrMagnitude <= 9) risk += o.sick == Sickness.Plague ? 2f : 1f;
}
if (Random.value < 0.0002f * risk * dt * 60f) CatchSickness();
}
else if (sick != Sickness.None)
{
sickDaysLeft -= dt / day;
if (sickDaysLeft <= 0f) { sick = Sickness.None; sickCooldown = 3f; AddThought("поправился", 3f, 1f); Notifier.Add(pname + " поправился(ась)"); }
}
for (int i = thoughts.Count - 1; i >= 0; i--)
{
Thought t = thoughts[i];
t.daysLeft -= dt / day;
if (t.daysLeft <= 0f) thoughts.RemoveAt(i);
else thoughts[i] = t;
}
if (Mood < 25f) lowMoodDays += dt / day;
else lowMoodDays = 0f;
if (!depressed && lowMoodDays > 1.5f) { depressed = true; AddThought("впал в депрессию", -10f, 3f); Notifier.Add(pname + " впал(а) в депрессию..."); }
if (depressed && Mood > 50f) { depressed = false; AddThought("выбрался из депрессии", 5f, 1f); }
if (giveUp) { giveUpTimer -= dt; if (giveUpTimer <= 0f) giveUp = false; }
energy = Mathf.Clamp(energy, 0f, 100f);
food = Mathf.Clamp(food, 0f, 100f);
fun = Mathf.Clamp(fun, 0f, 100f);
health = Mathf.Clamp(health, 0f, 100f);
stress = Mathf.Clamp(stress, 0f, 100f);
}
void CatchSickness()
{
float r = Random.value;
sick = r < 0.5f ? Sickness.Cold : r < 0.85f ? Sickness.Flu : Sickness.Plague;
sickDaysLeft = sick == Sickness.Cold ? 1f : sick == Sickness.Flu ? 2f : 3f;
AddThought("заболел (" + SickRu() + ")", sick == Sickness.Cold ? -3f : sick == Sickness.Flu ? -6f : -10f, sickDaysLeft);
Notifier.Add(pname + " заболел(а): " + SickRu());
}
void StartSleep()
{
state = State.Sleeping;
restTimer = 999f;
sleptTime = 0f;
sleepWasTired = true;
sleptOutside = !hasBed;
}
void StartBerry()
{
workTimer = BerryTimeNow();
workTotal = workTimer;
harvestingBerry = true;
state = State.Working;
}
float HarvestTimeNow()
{
int lvl = skills[SkillType.Farming].level;
return Mathf.Max(8f, 30f - lvl * 2f) * WorkMul();
}
float BerryTimeNow()
{
int lvl = skills[SkillType.Farming].level;
return Mathf.Max(2f, 8f - lvl * 0.5f) * WorkMul();
}
void Die()
{
Notifier.Add(pname + " ПОГИБ(ЛА)!");
foreach (Colonist o in all)
if (o != this)
{
if (o.socialPartner == this) o.FinishTalkSide();
o.AddThought(pname + " погиб(ла)", -12f, 2f);
}
if (hasBed) WorldGrid.OccupyBed(myBed, false);
AbandonBuild();
HideCarried();
SelectionManager.selected.Remove(this);
all.Remove(this);
Destroy(gameObject);
}
void Think()
{
if (stress >= 100f || Mood <= 5f) { StartBreakdown(); return; }
bool night = DayNightCycle.PhaseRu == "ночь";
bool wantsSleep = sick == Sickness.Plague || energy < 10f || sleepiness >= 90f || (night && sleepiness >= 80f);
if (wantsSleep && adrenaline < 50f)
{
bool soldier = socialClass == SocialClass.Soldier;
Vector2Int bed = WorldGrid.FindFreeBed(soldier);
if (bed.x != -1000)
{
hasBed = true; myBed = bed;
WorldGrid.OccupyBed(bed, true);
goingToSleep = true;
var p = Pathfinding.FindPath(CurrentCoord(), bed);
if (p != null) { hasJob = false; path = p; pathIndex = 0; pathTarget = bed; state = State.Moving; return; }
goingToSleep = false; WorldGrid.OccupyBed(bed, false); hasBed = false;
}
StartSleep();
return;
}
if (food < 30f && (Storage.food >= 2 || Storage.poisonFood >= 1) && WorldGrid.HasStockpile && !goingToEat)
{
var p = Pathfinding.FindPath(CurrentCoord(), WorldGrid.NearestStockpile(CurrentCoord()));
if (p != null) { goingToEat = true; hasJob = false; path = p; pathIndex = 0; state = State.Moving; return; }
}
if (socialClass == SocialClass.Worker && !giveUp)
{
// несёт ресурс - сначала донести на склад
if (carrying && WorldGrid.HasStockpile && !goingToDeliver)
{
Vector2Int spot = WorldGrid.NearestStockpileAccepting(CurrentCoord(), carryingType, carryingPoison);
if (spot.x != -1000)
{
var p = Pathfinding.FindPath(CurrentCoord(), spot);
if (p != null) { goingToDeliver = true; hasJob = false; path = p; pathIndex = 0; pathTarget = spot; state = State.Moving; return; }
}
}
bool allowHaul = WorldGrid.HasStockpile && energy > 30f;
if (JobQueue.TryTake(out Job j, allowHaul, CurrentCoord(), AcceptJob))
{
job = j;
hasJob = true;
ResetBuildFlags();
Vector2Int stand = j.type == JobType.Haul ? j.coord : ChooseStandTile(j.coord);
GoTo(stand);
if (state == State.Moving && path.Count == 0) ArriveAtJob();
return;
}
// помочь на стройке - только если есть материал и меньше 2 рабочих
foreach (var bp in BuildMode.blueprints)
{
if (BuildMode.BuilderCount(bp.Key) >= 2) continue;
if (BuildMode.GetProgress(bp.Key) >= 1f) continue;
if (!CanBuildWall(BuildMode.GetBlueprintType(bp.Key))) continue;
if (!BuildReady(bp.Key)) continue;
job = new Job(JobType.Build, bp.Key);
hasJob = true;
ResetBuildFlags();
GoTo(ChooseStandTile(bp.Key));
if (state == State.Moving && path.Count == 0) ArriveAtJob();
return;
}
// назначенные кликом кусты - в первую очередь
BerryBush db = NearestDesignatedRipeBush();
if (db != null)
{
targetBush = db; goingToBerry = true; hasJob = false;
GoTo(db.Coord);
if (state == State.Moving && path.Count == 0) { goingToBerry = false; StartBerry(); }
return;
}
}
else if (socialClass == SocialClass.Bourgeoisie)
{
if (state == State.Idle && !WorldGrid.IsDesk(CurrentCoord()) && Random.value < 0.01f)
{
Vector2Int d = WorldGrid.NearestDesk(CurrentCoord());
if (d.x != -1000)
{
var p = Pathfinding.FindPath(CurrentCoord(), d);
if (p != null && p.Count > 0) { hasJob = false; pathTarget = d; path = p; pathIndex = 0; state = State.Moving; return; }
}
}
yellCd -= Time.deltaTime;
if (yellCd <= 0f && Random.value < 0.01f)
{
Colonist victim = NearestWorker(6);
if (victim != null)
{
yellCd = 20f;
victim.stress = Mathf.Min(100f, victim.stress + 10f);
victim.boostTimer = 30f;
victim.AddThought("начальник накричал", -4f, 0.5f);
fun = Mathf.Min(100f, fun + 5f);
Notifier.Add(pname + " накричал(а) на " + victim.pname + " — тот работает быстрее, но злится");
}
}
}
else if (socialClass == SocialClass.Soldier)
{
trainCd -= Time.deltaTime;
if (trainCd <= 0f) { trainCd = 6f; GainSkill(SkillType.Ranged, 1f); }
patrolCd -= Time.deltaTime;
if (patrolCd <= 0f && state == State.Idle)
{
patrolCd = Random.Range(6f, 12f);
Vector2Int t = RandomPatrolPoint();
var pp = Pathfinding.FindPath(CurrentCoord(), t);
if (pp != null && pp.Count > 0) { hasJob = false; pathTarget = t; path = pp; pathIndex = 0; state = State.Moving; return; }
}
}
// поваляться - только при плохом настроении
if (Mood < 40f)
{
float lounge = trait == Trait.Lazy ? 0.003f : 0.0015f;
if (Random.value < lounge) { state = State.Sleeping; restTimer = Random.Range(2f, 5f); sleptTime = 0f; sleepWasTired = false; return; }
}
if (fun < 40f || Random.value < 0.002f)
{
Vector2Int t = ClampToMap(CurrentCoord() + new Vector2Int(Random.Range(-4, 5), Random.Range(-4, 5)));
var p = Pathfinding.FindPath(CurrentCoord(), t);
if (p != null && p.Count > 0) { hasJob = false; pathTarget = t; path = p; pathIndex = 0; state = State.Moving; return; }
}
if (Random.value < 0.003f && socialPartner == null)
{
Colonist other = NearestColonist(6);
if (other != null && other.state == State.Idle && other.socialPartner == null && !other.goingToTalk)
{
Vector2Int stand = ChooseStandTile(other.CurrentCoord());
var p = Pathfinding.FindPath(CurrentCoord(), stand);
if (p != null && p.Count > 0) { socialPartner = other; goingToTalk = true; hasJob = false; path = p; pathIndex = 0; pathTarget = stand; state = State.Moving; }
}
}
}
BerryBush NearestDesignatedRipeBush()
{
BerryBush best = null; float bd = float.MaxValue;
foreach (var b in BerryBush.all)
{
if (!b.hasBerries || !b.designated) continue;
float d = (b.Coord - CurrentCoord()).sqrMagnitude;
if (d < bd) { bd = d; best = b; }
}
return best;
}
Colonist NearestWorker(int radius)
{
Colonist best = null; float bd = radius * radius;
foreach (var o in all)
{
if (o == this || o.socialClass != SocialClass.Worker) continue;
if (o.state != State.Working && o.state != State.Moving) continue;
float d = (o.CurrentCoord() - CurrentCoord()).sqrMagnitude;
if (d <= bd) { bd = d; best = o; }
}
return best;
}
Vector2Int RandomPatrolPoint()
{
if (Random.value < 0.5f)
{
int side = Random.Range(0, 4);
int x = side == 0 ? Random.Range(0, 5) : side == 1 ? Random.Range(WorldGrid.Width - 5, WorldGrid.Width) : Random.Range(0, WorldGrid.Width);
int y = side == 2 ? Random.Range(0, 5) : side == 3 ? Random.Range(WorldGrid.Height - 5, WorldGrid.Height) : Random.Range(0, WorldGrid.Height);
return ClampToMap(new Vector2Int(x, y));
}
return ClampToMap(CurrentCoord() + new Vector2Int(Random.Range(-8, 9), Random.Range(-8, 9)));
}
Colonist NearestColonist(int radius)
{
Colonist best = null; float bd = radius * radius;
foreach (var o in all)
{
if (o == this) continue;
float d = (o.CurrentCoord() - CurrentCoord()).sqrMagnitude;
if (d <= bd) { bd = d; best = o; }
}
return best;
}
void TryStartTalk()
{
if (socialPartner == null) { state = State.Idle; return; }
if ((socialPartner.CurrentCoord() - CurrentCoord()).sqrMagnitude > 4) { socialPartner = null; state = State.Idle; return; }
if (socialPartner.state != State.Idle) { socialPartner = null; state = State.Idle; return; }
talkTimer = Random.Range(3f, 6f);
state = State.Talking;
socialPartner.BeginTalk(this, talkTimer);
}
public void BeginTalk(Colonist initiator, float timer)
{
if (state != State.Idle) return;
socialPartner = initiator;
talkTimer = timer;
state = State.Talking;
}
void FinishTalk()
{
Colonist other = socialPartner;
socialPartner = null;
state = State.Idle;
if (other != null && other.socialPartner == this) other.FinishTalkSide();
if (other == null) return;
if (Random.value < 0.25f)
{
AddThought("поругался с " + other.pname, -5f, 1f);
other.AddThought("поругался с " + pname, -5f, 1f);
stress = Mathf.Min(100f, stress + 10f);
other.stress = Mathf.Min(100f, other.stress + 10f);
Notifier.Add(pname + " и " + other.pname + " поругались");
GainSkill(SkillType.Social, 1f);
if (Random.value < 0.35f) StartFight(other);
}
else
{
fun = Mathf.Min(100f, fun + 12f);
other.fun = Mathf.Min(100f, other.fun + 12f);
AddThought("поболтал с " + other.pname, 4f, 0.5f);
other.AddThought("поболтал с " + pname, 4f, 0.5f);
GainSkill(SkillType.Social, 1f);
}
}
void StartFight(Colonist other)
{
adrenaline = 100f; other.adrenaline = 100f;
stress = Mathf.Min(100f, stress + 15f); other.stress = Mathf.Min(100f, other.stress + 15f);
health -= 5f; other.health -= 5f;
AddThought("подрался с " + other.pname, -6f, 1f);
other.AddThought("подрался с " + pname, -6f, 1f);
GainSkill(SkillType.Melee, 1f); other.GainSkill(SkillType.Melee, 1f);
Notifier.Add(pname + " и " + other.pname + " ПОДРАЛИСЬ!");
}
public void FinishTalkSide() { socialPartner = null; if (state == State.Talking) state = State.Idle; }
void LeaveTalk()
{
if (state != State.Talking) return;
Colonist other = socialPartner;
socialPartner = null;
state = State.Idle;
if (other != null && other.socialPartner == this) other.FinishTalkSide();
}
void StartBreakdown()
{
LeaveTalk();
state = State.Breakdown;
breakdownTimer = Random.Range(6f, 10f);
panicTimer = 0f;
if (hasJob) { JobQueue.Requeue(job); hasJob = false; AbandonBuild(); }
if (carrying) DropCarried();
goingToEat = false; goingToTalk = false; goingToSleep = false; goingToBerry = false; goingToDeliver = false;
if (socialClass == SocialClass.Worker && Random.value < 0.6f)
{
breakKind = BreakKind.Strike;
giveUp = true;
giveUpTimer = Random.Range(20f, 35f);
Notifier.Add(pname + " ЗАБАСТОВАЛ(А)! Профсоюз требует хлеба и сна!");
}
else switch (trait)
{
case Trait.Panicker: case Trait.Nervous: breakKind = BreakKind.Panic; break;
case Trait.Lazy: case Trait.Wimp: case Trait.Ascetic: breakKind = BreakKind.Stupor; break;
case Trait.Hardworking: case Trait.Tough: case Trait.Workaholic: breakKind = BreakKind.Tantrum; break;
case Trait.Gourmand: breakKind = BreakKind.Binge; break;
default: breakKind = Random.value < 0.5f ? BreakKind.GiveUp : BreakKind.Panic; break;
}
if (breakKind == BreakKind.Tantrum) SmashRandomWall();
else if (breakKind == BreakKind.Binge && Storage.food >= 20) { Storage.food -= 20; fun = Mathf.Min(100f, fun + 30f); health -= 5f; AddThought("объелся", 5f, 1f); }
AddThought("нервный срыв", -8f, 2f);
Notifier.Add(pname + ": нервный срыв (" + BreakRu() + ")");
}
void UpdateBreakdown()
{
breakdownTimer -= Time.deltaTime;
if (breakKind == BreakKind.Panic)
{
panicTimer -= Time.deltaTime;
if (panicTimer <= 0f && !movement.IsMoving)
{
panicTimer = 0.4f;
Vector2Int t = ClampToMap(CurrentCoord() + new Vector2Int(Random.Range(-3, 4), Random.Range(-3, 4)));
var p = Pathfinding.FindPath(CurrentCoord(), t);
if (p != null) { path = p; pathIndex = 0; }
}
StepPath();
}
if (breakdownTimer <= 0f) { stress = 40f; state = State.Idle; }
}
void SmashRandomWall()
{
List<Vector2Int> candidates = new List<Vector2Int>();
Vector2Int me = CurrentCoord();
for (int dx = -3; dx <= 3; dx++)
for (int dy = -3; dy <= 3; dy++)
{
Vector2Int c = me + new Vector2Int(dx, dy);
if (WorldGrid.IsWall(c)) candidates.Add(c);
}
if (candidates.Count == 0) return;
Vector2Int target = candidates[Random.Range(0, candidates.Count)];
WallAutoTile w = WorldGrid.GetWall(target);
if (w != null) Destroy(w.gameObject);
WorldGrid.RemoveWall(target);
Notifier.Add(pname + " в истерике сломал(а) стену!");
foreach (Colonist o in all) if (o != this) o.AddThought("видел истерику " + pname, -4f, 1f);
}
void GoTo(Vector2Int target)
{
var p = Pathfinding.FindPath(CurrentCoord(), target);
if (p == null) { JobQueue.Requeue(job); hasJob = false; AbandonBuild(); return; }
path = p; pathIndex = 0; pathTarget = target; state = State.Moving;
}
public void OrderMove(Vector2Int target)
{
if (state == State.Breakdown || state == State.Exhausted) return;
LeaveTalk();
goingToTalk = false; goingToSleep = false; goingToBerry = false; goingToDeliver = false;
if (carrying) DropCarried();
if (hasJob) { JobQueue.Requeue(job); hasJob = false; AbandonBuild(); }
goingToEat = false;
var p = Pathfinding.FindPath(CurrentCoord(), target);
if (p != null) { path = p; pathIndex = 0; pathTarget = target; state = State.Moving; }
}
void DropCarried()
{
DropFactory.Spawn(CurrentCoord(), carryingType, carryingAmount, poison: carryingPoison);
carrying = false; carryingRefund = false; carryingPoison = false; carryingAmount = 0;
HideCarried();
}
void StepPath()
{
if (pathIndex < path.Count && !movement.IsMoving)
{
Vector2Int n = path[pathIndex];
if (!WorldGrid.IsPathPassable(n))
{
var p = Pathfinding.FindPath(CurrentCoord(), pathTarget);
if (p != null) { path = p; pathIndex = 0; return; }
if (hasJob) { JobQueue.Requeue(job); hasJob = false; AbandonBuild(); }
goingToEat = false; goingToTalk = false; goingToSleep = false; goingToBerry = false; goingToDeliver = false; socialPartner = null;
path.Clear(); state = State.Idle; return;
}
var cur = WorldGrid.GetDoor(CurrentCoord());
if (cur != null && cur.isOpen) cur.SetOpen(false);
var nd = WorldGrid.GetDoor(n);
if (nd != null && !nd.isOpen) nd.SetOpen(true);
pathIndex++;
movement.MoveTo(new Vector3(n.x, n.y, 0));
}
}
void ArriveAtJob()
{
switch (job.type)
{
case JobType.Build:
if (!BuildMode.blueprints.ContainsKey(job.coord)) { ResetBuildFlags(); hasJob = false; state = State.Idle; break; }
if (!CanBuildWall(BuildMode.GetBlueprintType(job.coord))) { JobQueue.Requeue(job); hasJob = false; ResetBuildFlags(); state = State.Idle; break; }
// принёс материал - отдать чертежу и строить
if (buildHasMat)
{
buildHasMat = false;
HideCarried();
carryingAmount = 0;
StartBuildNow();
break;
}
// идёт брать дроп с земли
if (buildFetchDrop)
{
buildFetchDrop = false;
var d = WorldGrid.GetDrop(fetchDropCoord);
if (d != null)
{
BuildMode.BlueprintCost(job.coord, out var rt, out var cost);
int take = Mathf.Min(d.amount, cost);
d.amount -= take;
if (d.amount <= 0) { WorldGrid.RemoveDrop(fetchDropCoord); Destroy(d.gameObject); }
carryingType = d.type; carryingAmount = take; carryingPoison = false; carryingRefund = false;
ShowCarried();
buildHasMat = true;
}
GoTo(ChooseStandTile(job.coord));
break;
}
// идёт брать со склада (из банка)
if (buildFetch)
{
buildFetch = false;
BuildMode.BlueprintCost(job.coord, out var rt2, out var cost2);
if (BankHas(rt2, cost2))
{
BankTake(rt2, cost2);
carryingType = rt2; carryingAmount = cost2; carryingPoison = false; carryingRefund = false;
ShowCarried();
buildHasMat = true;
}
GoTo(ChooseStandTile(job.coord));
break;
}
// решить, откуда брать: СНАЧАЛА дропы с земли, потом склад
{
BuildMode.BlueprintCost(job.coord, out var res, out var cost);
fetchType = res; fetchCost = cost;
var drop = NearestDropOf(res);
if (drop != null) { buildFetchDrop = true; fetchDropCoord = drop.Coord; GoTo(drop.Coord); break; }
if (WorldGrid.HasStockpile && BankHas(res, cost)) { buildFetch = true; GoTo(WorldGrid.NearestStockpile(CurrentCoord())); break; }
// материала нет нигде - чертёж ждёт
JobQueue.Requeue(job); hasJob = false; ResetBuildFlags(); state = State.Idle;
break;
}
case JobType.Harvest:
StartWork(HarvestTimeNow());
break;
case JobType.Haul:
if (carrying) Deposit();
else PickUp();
break;
}
}
void StartBuildNow()
{
BuildMode.AddBuilder(job.coord);
isBuilderNow = true;
float t = BuildTimeNow(BuildMode.GetBlueprintType(job.coord)) * WorkMul();
myBuildRate = 1f / t;
if (BuildMode.BuilderCount(job.coord) >= 2) myBuildRate *= 0.75f;
workTotal = t; workTimer = t;
state = State.Working;
}
float WorkMul()
{
float m = TraitWorkMul;
if (boostTimer > 0f) m *= 0.8f;
if (Mood < 40f) m *= 1.4f;
if (depressed) m *= 1.5f;
if (injured) m *= 1.3f;
if (sleepiness > 80f) m *= 1.3f;
if (sick == Sickness.Cold) m *= 1.2f;
else if (sick == Sickness.Flu) m *= 1.5f;
else if (sick == Sickness.Plague) m *= 2f;
return m;
}
void StartWork(float t) { workTimer = t; workTotal = t; state = State.Working; }
void FinishWork()
{
if (harvestingBerry)
{
if (targetBush != null) { targetBush.designated = false; targetBush.Harvest(this); }
GainSkill(SkillType.Farming, 1f);
harvestingBerry = false; targetBush = null; hasJob = false; state = State.Idle;
return;
}
if (job.type == JobType.Build)
{
if (isBuilderNow) BuildMode.RemoveBuilder(job.coord);
isBuilderNow = false;
ApplyBuild();
BuildMode.ClearBuild(job.coord);
GainSkill(SkillType.Construction, 1f);
ResetBuildFlags();
Notifier.Add(pname + ": построил(а) (" + job.coord.x + "," + job.coord.y + ")");
}
else if (job.type == JobType.Harvest)
{
ApplyHarvest();
GainSkill(SkillType.Farming, 2f);
GainSkill(SkillType.Endurance, 1f);
}
if (Random.value < 0.02f && !injured)
{
injured = true;
health -= 10f;
AddThought("травма на работе", -6f, 2f);
Notifier.Add(pname + " травмировался(ась) на работе!");
}
hasJob = false;
state = State.Idle;
}
void ApplyBuild()
{
if (!BuildMode.blueprints.TryGetValue(job.coord, out GameObject bp) || bp == null) return;
BuildMode.blueprints.Remove(job.coord);
BuildMode.blueprintTypes.Remove(job.coord);
var kind = BuildMode.GetBlueprintKind(job.coord);
BuildMode.blueprintKinds.Remove(job.coord);
if (bp != null) bp.GetComponent<SpriteRenderer>().color = Color.white;
BuildMode.designated.Remove(job.coord);
if (kind == BuildMode.BuildKind.Wall) { WorldGrid.SetBlocked(job.coord); WorldGrid.RefreshWall(job.coord); WorldGrid.RecomputeRooms(); }
else if (kind == BuildMode.BuildKind.Bed) { WorldGrid.AddBed(job.coord, false); WorldGrid.SetFurnObj(job.coord, bp); }
else if (kind == BuildMode.BuildKind.Cot) { WorldGrid.AddBed(job.coord, true); WorldGrid.SetFurnObj(job.coord, bp); }
else if (kind == BuildMode.BuildKind.Desk) { WorldGrid.AddDesk(job.coord); WorldGrid.SetFurnObj(job.coord, bp); }
else if (kind == BuildMode.BuildKind.Door) { var d = bp.GetComponent<Door>(); if (d != null) d.Register(); }
}
// добыча больше НЕ кладёт ресурс в банк - только дроп на землю
void ApplyHarvest()
{
ResourceNode node = WorldGrid.GetResource(job.coord);
if (node == null) return;
Notifier.Add(pname + ": добыл(а) " + node.type + " +" + node.amount);
Vector2Int c = node.Coord; ResourceType t = node.type; int a = node.amount;
WorldGrid.RemoveResource(c);
WorldGrid.SetFree(c);
Destroy(node.gameObject);
DropFactory.Spawn(c, t, a);
}
void PickUp()
{
ResourceDrop drop = WorldGrid.GetDrop(job.coord);
if (drop == null || !WorldGrid.HasStockpile) { hasJob = false; state = State.Idle; return; }
carrying = true;
carryingType = drop.type;
carryingAmount = drop.amount;
carryingRefund = drop.refund;
carryingPoison = drop.poison;
WorldGrid.RemoveDrop(job.coord);
Destroy(drop.gameObject);
ShowCarried();
Vector2Int spot = WorldGrid.NearestStockpileAccepting(CurrentCoord(), carryingType, carryingPoison);
if (spot.x == -1000) spot = WorldGrid.NearestStockpile(CurrentCoord());
var p = Pathfinding.FindPath(CurrentCoord(), spot);
if (p == null) { DropCarried(); hasJob = false; state = State.Idle; return; }
path = p; pathIndex = 0; pathTarget = spot; state = State.Moving;
}
// доставка на склад: банк пополняется только здесь
void Deposit()
{
if (carryingPoison) Storage.poisonFood += carryingAmount;
else Storage.Add(carryingType, carryingAmount);
GainSkill(SkillType.Endurance, 1f);
var pile = DropFactory.Spawn(
WorldGrid.NearestStockpile(CurrentCoord()), carryingType, carryingAmount,
addHaulJob: false, register: true,
offset: new Vector3(Random.Range(-0.25f, 0.25f), Random.Range(-0.25f, 0.25f), 0),
poison: carryingPoison);
HideCarried();
carrying = false; carryingRefund = false; carryingPoison = false; carryingAmount = 0;
goingToDeliver = false;
hasJob = false;
state = State.Idle;
}
Vector2Int ChooseStandTile(Vector2Int target)
{
Vector2Int[] neighbors =
{
new Vector2Int(target.x + 1, target.y), new Vector2Int(target.x - 1, target.y),
new Vector2Int(target.x, target.y + 1), new Vector2Int(target.x, target.y - 1),
};
Vector2Int best = target;
float bestDist = float.MaxValue;
foreach (var n in neighbors)
{
if (!WorldGrid.InBounds(n) || WorldGrid.IsBlocked(n)) continue;
float d = (n - CurrentCoord()).sqrMagnitude;
if (d < bestDist) { bestDist = d; best = n; }
}
return best;
}
Vector2Int ClampToMap(Vector2Int c) => new Vector2Int(Mathf.Clamp(c.x, 0, WorldGrid.Width - 1), Mathf.Clamp(c.y, 0, WorldGrid.Height - 1));
public Vector2Int CurrentCoord() => new Vector2Int(Mathf.RoundToInt(transform.position.x), Mathf.RoundToInt(transform.position.y));
}