using UnityEngine;

public enum ZoneType { Stockpile, Trash, Garden }

public class StockpileZone
{
    static int nextId = 1;
    public int id;
    public ZoneType type;
    public RectInt rect;

    // фильтры склада
    public bool acceptWood = true;
    public bool acceptStone = true;
    public bool acceptBerries = true;
    public bool acceptPoison = true;
    public bool acceptCorpses = false; // на будущее
    public bool acceptWeapons = false;
    public bool acceptClothes = false;

    public StockpileZone(ZoneType t, RectInt r) { id = nextId++; type = t; rect = r; }

    public bool Contains(Vector2Int c) =>
        c.x >= rect.xMin && c.x < rect.xMax && c.y >= rect.yMin && c.y < rect.yMax;

    public bool Accepts(ResourceType t, bool poison)
    {
        if (type == ZoneType.Trash) return true;      // мусор принимает всё
        if (type != ZoneType.Stockpile) return false; // огород - нет
        if (t == ResourceType.Wood) return acceptWood;
        if (t == ResourceType.Stone) return acceptStone;
        return poison ? acceptPoison : acceptBerries;
    }
}