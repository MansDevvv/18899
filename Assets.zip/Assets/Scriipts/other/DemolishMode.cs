using UnityEngine;

// X - режим сноса/отмены, ЛКМ - снести/отменить, ПКМ/Esc - выход
public class DemolishMode : MonoBehaviour
{
    public static bool IsActive { get; private set; }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.X)) IsActive = !IsActive;
        if (!IsActive) return;
        if (GameUI.BlockInput) return;
        if (Input.GetKeyDown(KeyCode.Escape) || Input.GetMouseButtonDown(1)) { IsActive = false; return; }

        if (Input.GetMouseButtonDown(0))
        {
            Vector2Int c = WorldGrid.MouseCoord();
            if (BuildMode.blueprints.ContainsKey(c)) CancelBlueprint(c);
            else if (WorldGrid.IsDoor(c)) DemolishDoor(c);
            else if (WorldGrid.IsBed(c) || WorldGrid.IsDesk(c)) DemolishFurniture(c);
            else if (WorldGrid.IsWall(c)) DemolishWall(c);
        }
    }

    // отмена чертежа - полный возврат
    void CancelBlueprint(Vector2Int c)
    {
        if (BuildMode.blueprints.TryGetValue(c, out GameObject bp) && bp != null)
            Destroy(bp);

        var kind = BuildMode.GetBlueprintKind(c);
        BuildMode.blueprints.Remove(c);
        BuildMode.blueprintTypes.Remove(c);
        BuildMode.blueprintKinds.Remove(c);
        BuildMode.designated.Remove(c);
        WorldGrid.SetFree(c);
        WorldGrid.RecomputeRooms();

        // найдём предмет, чтобы вернуть его стоимость
        BuildMode.BuildItem item = null;
        foreach (var it in BuildMode.items)
        {
            if (it.kind != kind) continue;
            if (kind == BuildMode.BuildKind.Wall && it.wallType != BuildMode.GetBlueprintType(c)) continue;
            item = it;
            break;
        }
        ResourceType res = item != null ? item.costType : ResourceType.Wood;
        int refund = item != null ? item.cost : 10;
        GiveRefund(c, res, refund);
        Debug.Log("Отменена постройка, возврат " + refund + " (" + res + ")");
    }

    void DemolishDoor(Vector2Int c)
    {
        var d = WorldGrid.GetDoor(c);
        if (d != null) { d.Unregister(); Destroy(d.gameObject); }
        GiveRefund(c, ResourceType.Wood, 10 - 2);
        Debug.Log("Дверь снесена");
    }

    void DemolishFurniture(Vector2Int c)
    {
        int cost;
        if (WorldGrid.IsDesk(c)) { WorldGrid.RemoveDesk(c); cost = 30; }
        else { bool soldier = WorldGrid.IsSoldierBed(c); WorldGrid.RemoveBed(c); cost = soldier ? 15 : 20; }
        GiveRefund(c, ResourceType.Wood, cost - 2);
        Debug.Log("Мебель снесена");
    }

    void DemolishWall(Vector2Int c)
    {
        WallAutoTile w = WorldGrid.GetWall(c);
        ResourceType res = w != null ? w.refundType : ResourceType.Wood;
        if (w != null) Destroy(w.gameObject);
        WorldGrid.RemoveWall(c);

        int cost = res == ResourceType.Wood ? BuildMode.WoodCost : BuildMode.StoneCost;
        GiveRefund(c, res, cost - 2);
        Debug.Log("Стена снесена: упало " + Mathf.Max(0, cost - 2) + " (" + res + ")");
    }

    void GiveRefund(Vector2Int c, ResourceType res, int amount)
    {
        int refund = Mathf.Max(0, amount);
        var drop = DropFactory.Spawn(c, res, refund);
        if (drop != null) drop.refund = true;
    }
}