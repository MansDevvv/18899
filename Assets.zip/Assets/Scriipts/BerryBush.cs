using System.Collections.Generic;
using UnityEngine;

public class BerryBush : MonoBehaviour
{
    public bool poisonous;
    public Sprite ripeSprite;
    public Sprite harvestedSprite;
    public GameObject dropPrefab;
    public float regrowDays = 5f;
    public bool hasBerries = true;
    public bool designated; // назначен сбор кликом

    float regrowTimer;
    SpriteRenderer sr;

    public static readonly List<BerryBush> all = new List<BerryBush>();

    public Vector2Int Coord => new Vector2Int(Mathf.RoundToInt(transform.position.x), Mathf.RoundToInt(transform.position.y));

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
        all.Add(this);
        Apply();
    }

    void OnDestroy() { all.Remove(this); }

    void Apply()
    {
        if (sr != null) sr.sprite = hasBerries ? ripeSprite : harvestedSprite;
    }

    void Update()
    {
        if (!hasBerries)
        {
            regrowTimer -= Time.deltaTime;
            if (regrowTimer <= 0f) { hasBerries = true; Apply(); }
        }
    }

    public static BerryBush At(Vector2Int c)
    {
        foreach (var b in all)
            if (b.Coord == c) return b;
        return null;
    }

    public void Harvest(Colonist by)
    {
        if (!hasBerries) return;
        hasBerries = false;
        designated = false;
        regrowTimer = regrowDays * GameTime.dayLength;
        Apply();

        var exist = WorldGrid.GetDrop(Coord);
        if (exist != null && exist.type == ResourceType.Food && exist.poison == poisonous && exist.amount < 100)
        {
            exist.amount += 1;
            JobQueue.Add(JobType.Haul, Coord);
        }
        else if (dropPrefab != null)
        {
            GameObject d = Instantiate(dropPrefab, new Vector3(Coord.x, Coord.y, 0), Quaternion.identity);
            var rd = d.GetComponent<ResourceDrop>();
            if (rd != null)
            {
                rd.type = ResourceType.Food;
                rd.amount = 1;
                rd.refund = true;
                rd.poison = poisonous;
                WorldGrid.AddDrop(rd);
                JobQueue.Add(JobType.Haul, Coord);
            }
        }
    }
}