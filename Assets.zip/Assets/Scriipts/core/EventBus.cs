using System;
using System.Collections.Generic;
using UnityEngine;
// Типизированная шина событий: системы общаются событиями, а не перебором всего мира.
public static class EventBus
{
    static readonly Dictionary<Type, List<Delegate>> subs = new Dictionary<Type, List<Delegate>>();
    public static void Subscribe<T>(Action<T> h)
    {
        if (h == null) return;
        if (!subs.TryGetValue(typeof(T), out var list)) { list = new List<Delegate>(); subs[typeof(T)] = list; }
        if (!list.Contains(h)) list.Add(h);
    }
    public static void Unsubscribe<T>(Action<T> h)
    {
        if (h == null) return;
        if (subs.TryGetValue(typeof(T), out var list)) list.Remove(h);
    }
    public static void Raise<T>(T evt)
    {
        if (!subs.TryGetValue(typeof(T), out var list)) return;
        var copy = new List<Delegate>(list); // безопасно к отписке во время перебора
        foreach (var d in copy)
        {
            try { ((Action<T>)d).Invoke(evt); }
            catch (Exception e) { Debug.LogError("[EventBus] " + typeof(T).Name + ": " + e); }
        }
    }
    public static void Clear() => subs.Clear();
}