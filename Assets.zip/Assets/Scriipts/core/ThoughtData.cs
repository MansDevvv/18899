using UnityEngine;
// Мысль новой архитектуры: источник, сила, длительность, время создания.
// Mood (Этап 3) суммирует активные мысли; старые "спал на земле", "видел труп" и т.д. станут sourceId.
[System.Serializable]
public class ThoughtData
{
    public string sourceId = "";
    public string text = "";
    public float value = 0f;        // модификатор настроения (+/-)
    public float durationDays = 1f;
    public float createdTime = 0f;  // GameTime.time в момент создания
    public bool IsExpired => GameTime.time - createdTime >= durationDays * GameTime.dayLength;
    public float AgeDays => (GameTime.time - createdTime) / Mathf.Max(0.0001f, GameTime.dayLength);
}