using UnityEngine;
// Структуры событий. События задач (JobAdded/JobTaken/...) появятся в Этапе 2 вместе с JobBoard.
public struct ItemSpawnedEvent { public ItemStack item; public ItemSpawnedEvent(ItemStack i) { item = i; } }
public struct ItemRemovedEvent { public ItemStack item; public ItemRemovedEvent(ItemStack i) { item = i; } }
public struct ItemChangedEvent { public ItemStack item; public ItemChangedEvent(ItemStack i) { item = i; } }
public struct ItemsReservedEvent
{
    public ItemStack item; public MonoBehaviour holder; public int amount;
    public ItemsReservedEvent(ItemStack i, MonoBehaviour h, int a) { item = i; holder = h; amount = a; }
}
public struct ItemsReleasedEvent
{
    public ItemStack item; public MonoBehaviour holder;
    public ItemsReleasedEvent(ItemStack i, MonoBehaviour h) { item = i; holder = h; }
}
public struct SlotReservedEvent
{
    public Object target; public MonoBehaviour holder;
    public SlotReservedEvent(Object t, MonoBehaviour h) { target = t; holder = h; }
}
public struct SlotReleasedEvent
{
    public Object target; public MonoBehaviour holder;
    public SlotReleasedEvent(Object t, MonoBehaviour h) { target = t; holder = h; }
}