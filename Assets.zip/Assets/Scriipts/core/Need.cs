using UnityEngine;
// Универсальная потребность. Любая новая потребность (жажда, комфорт, ...) - просто экземпляр.
// Пороги абсолютные, как в ТЗ: 100 сыт / 60 норма / 30 голоден / 10 критический / 0 последствия.
public enum NeedStatus { Ok, Warning, Critical, Empty }
[System.Serializable]
public class Need
{
    public string id = "need";
    public float maxValue = 100f;
    public float currentValue = 100f;
    public float decayRate = 0f;      // единиц в секунду при расходовании
    public float recoveryRate = 0f;   // единиц в секунду при восстановлении
    public float warningThreshold = 30f;
    public float criticalThreshold = 10f;
    public float Value => currentValue;
    public float Normalized => maxValue > 0f ? Mathf.Clamp01(currentValue / maxValue) : 0f;
    public bool IsWarning => currentValue <= warningThreshold;
    public bool IsCritical => currentValue <= criticalThreshold;
    public bool IsEmpty => currentValue <= 0f;
    public NeedStatus Status => IsEmpty ? NeedStatus.Empty : IsCritical ? NeedStatus.Critical : IsWarning ? NeedStatus.Warning : NeedStatus.Ok;
    public void TickDecay(float dt, float mult = 1f) => Change(-decayRate * mult * dt);
    public void TickRecovery(float dt, float mult = 1f) => Change(recoveryRate * mult * dt);
    public void Change(float delta) => currentValue = Mathf.Clamp(currentValue + delta, 0f, maxValue); // никогда не уходит в минус
    public void Set(float v) => currentValue = Mathf.Clamp(v, 0f, maxValue);
}