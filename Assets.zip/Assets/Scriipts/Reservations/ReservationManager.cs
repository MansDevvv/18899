using System.Collections.Generic;
using UnityEngine;
// Общая система резерваций: предметы (по количеству) и слоты (один владелец).
// Покрывает: ресурсы/предметы, кровати, станки, рабочие места, объекты - без отдельных костылей.
public static class ReservationManager
{
    struct ItemRes { public MonoBehaviour holder; public int amount; }
    static readonly Dictionary<ItemStack, List<ItemRes>> itemRes = new Dictionary<ItemStack, List<ItemRes>>();
    static readonly Dictionary<Object, MonoBehaviour> slotRes = new Dictionary<Object, MonoBehaviour>();

    // ===== ПРЕДМЕТЫ =====
    public static int ReservedAmount(ItemStack s)
    {
        if (s == null || !itemRes.TryGetValue(s, out var list)) return 0;
        int sum = 0;
        foreach (var r in list) sum += r.amount;
        return sum;
    }
    public static int AvailableAmount(ItemStack s) => s == null ? 0 : Mathf.Max(0, s.amount - ReservedAmount(s));
    // Резервирует до amount; возвращает, сколько реально взял (0 = нечего брать).
    // Повторный резерв тем же holder'ом сливается - двойной резервации нет.
    public static int TryReserveItems(MonoBehaviour holder, ItemStack s, int amount)
    {
        if (holder == null || s == null || amount <= 0) return 0;
        int can = Mathf.Min(amount, AvailableAmount(s));
        if (can <= 0) return 0;
        if (!itemRes.TryGetValue(s, out var list)) { list = new List<ItemRes>(); itemRes[s] = list; }
        for (int i = 0; i < list.Count; i++)
            if (list[i].holder == holder)
            {
                var r = list[i]; r.amount += can; list[i] = r;
                EventBus.Raise(new ItemsReservedEvent(s, holder, can));
                return can;
            }
        list.Add(new ItemRes { holder = holder, amount = can });
        EventBus.Raise(new ItemsReservedEvent(s, holder, can));
        return can;
    }
    public static void ReleaseItems(MonoBehaviour holder, ItemStack s)
    {
        if (holder == null || s == null || !itemRes.TryGetValue(s, out var list)) return;
        for (int i = list.Count - 1; i >= 0; i--)
            if (list[i].holder == holder) { list.RemoveAt(i); EventBus.Raise(new ItemsReleasedEvent(s, holder)); }
        if (list.Count == 0) itemRes.Remove(s);
    }
    // Полная очистка за погибшим/уничтоженным - резервации не "виснут".
    public static void ReleaseAllBy(MonoBehaviour holder)
    {
        if (holder == null) return;
        foreach (var kv in new Dictionary<ItemStack, List<ItemRes>>(itemRes))
        {
            bool touched = false;
            for (int i = kv.Value.Count - 1; i >= 0; i--)
                if (kv.Value[i].holder == holder) { kv.Value.RemoveAt(i); touched = true; }
            if (touched)
            {
                EventBus.Raise(new ItemsReleasedEvent(kv.Key, holder));
                if (kv.Value.Count == 0) itemRes.Remove(kv.Key);
            }
        }
        foreach (var kv in new Dictionary<Object, MonoBehaviour>(slotRes))
            if (kv.Value == holder) slotRes.Remove(kv.Key);
    }
    // Страховка от мёртвых ссылок (вызывать редко, например при загрузке сцены).
    public static void PurgeDead()
    {
        foreach (var kv in new Dictionary<ItemStack, List<ItemRes>>(itemRes))
        {
            if (kv.Key == null) { itemRes.Remove(kv.Key); continue; }
            kv.Value.RemoveAll(r => r.holder == null);
            if (kv.Value.Count == 0) itemRes.Remove(kv.Key);
        }
        foreach (var kv in new Dictionary<Object, MonoBehaviour>(slotRes))
            if (kv.Key == null || kv.Value == null) slotRes.Remove(kv.Key);
    }

    // ===== СЛОТЫ (кровать/станок/рабочее место/объект) =====
    public static bool TryReserveSlot(MonoBehaviour holder, Object target)
    {
        if (holder == null || target == null) return false;
        if (slotRes.TryGetValue(target, out var h))
        {
            if (h == holder) return true;      // уже мой - не дублируем
            if (h != null) return false;       // занят другим
            slotRes.Remove(target);            // владелец умер - слот освобождаем
        }
        slotRes[target] = holder;
        EventBus.Raise(new SlotReservedEvent(target, holder));
        return true;
    }
    public static void ReleaseSlot(MonoBehaviour holder, Object target)
    {
        if (holder == null || target == null) return;
        if (slotRes.TryGetValue(target, out var h) && h == holder)
        {
            slotRes.Remove(target);
            EventBus.Raise(new SlotReleasedEvent(target, holder));
        }
    }
    public static bool IsSlotReserved(Object target) => target != null && slotRes.TryGetValue(target, out var h) && h != null;
    public static bool IsSlotReservedBy(Object target, MonoBehaviour holder) => target != null && slotRes.TryGetValue(target, out var h) && h == holder;
    public static void Clear() { itemRes.Clear(); slotRes.Clear(); }
}