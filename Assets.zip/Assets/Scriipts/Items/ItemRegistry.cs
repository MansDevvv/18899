using System.Collections.Generic;
using UnityEngine;
// Реестр всех физических предметов. Запросы локальные (ближайший доступный),
// без центрального менеджера, сканирующего весь мир каждый кадр.
public static class ItemRegistry
{
    static readonly List<ItemStack> items = new List<ItemStack>();
    public static IReadOnlyList<ItemStack> All => items;
    public static int Count => items.Count;
    public static void Add(ItemStack s)
    {
        if (s == null || items.Contains(s)) return;
        items.Add(s);
        EventBus.Raise(new ItemSpawnedEvent(s));
    }
    public static void Remove(ItemStack s)
    {
        if (s == null) return;
        if (items.Remove(s)) EventBus.Raise(new ItemRemovedEvent(s));
    }
    public static ItemStack GetAt(Vector2Int c)
    {
        for (int i = 0; i < items.Count; i++)
            if (items[i] != null && items[i].Coord == c) return items[i];
        return null;
    }
    // Ближайший стак нужного типа со свободным (не зарезервированным) количеством.
    public static ItemStack NearestAvailable(ResourceType t, bool poison, Vector2Int from, int min = 1)
    {
        ItemStack best = null; float bd = float.MaxValue;
        for (int i = 0; i < items.Count; i++)
        {
            var s = items[i];
            if (s == null || s.type != t || s.poison != poison) continue;
            if (ReservationManager.AvailableAmount(s) < min) continue;
            float d = (s.Coord - from).sqrMagnitude;
            if (d < bd) { bd = d; best = s; }
        }
        return best;
    }
    public static int TotalAvailable(ResourceType t, bool poison = false)
    {
        int sum = 0;
        for (int i = 0; i < items.Count; i++)
        {
            var s = items[i];
            if (s != null && s.type == t && s.poison == poison) sum += ReservationManager.AvailableAmount(s);
        }
        return sum;
    }
    public static void Clear() { items.Clear(); }
}