using UnityEngine;
// Физический предмет мира: дроп на земле, куча на складе (позже - изделия, трупы...).
// Базовый класс; ResourceDrop (часть 2) наследует его и добавляет refund.
public class ItemStack : MonoBehaviour
{
    public ResourceType type = ResourceType.Wood;
    public int amount = 1;
    public bool poison;
    public bool registered { get; private set; }
    public Vector2Int Coord => new Vector2Int(Mathf.RoundToInt(transform.position.x), Mathf.RoundToInt(transform.position.y));
    public void Register()
    {
        if (registered) return;
        registered = true;
        ItemRegistry.Add(this);
    }
    public void SetAmount(int v)
    {
        amount = Mathf.Max(0, v); // отрицательное количество невозможно
        EventBus.Raise(new ItemChangedEvent(this));
    }
    public void AddAmount(int v) => SetAmount(amount + v);
    void OnDestroy()
    {
        if (registered) { registered = false; ItemRegistry.Remove(this); } // ровно одна отписка
    }
}