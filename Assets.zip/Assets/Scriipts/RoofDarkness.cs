using System.Collections.Generic;
using UnityEngine;
// Рисует тёмную "крышу" над замкнутыми помещениями
public class RoofDarkness : MonoBehaviour
{
    [Range(0f, 1f)] public float darkness = 0.45f;
    public int sortingOrder = 20;
    MeshFilter mf; MeshRenderer mr; Mesh mesh; Material mat;
    void Awake()
    {
        mf = gameObject.AddComponent<MeshFilter>();
        mr = gameObject.AddComponent<MeshRenderer>();
        mesh = new Mesh();
        mesh.vertices = new Vector3[4];
        mf.sharedMesh = mesh;
        var sh = Shader.Find("Sprites/Default");
        if (sh == null) sh = Shader.Find("Unlit/Transparent");
        mat = new Material(sh);
        mr.sharedMaterial = mat;
        mr.sortingOrder = sortingOrder;
        WorldGrid.OnRoomsChanged += Rebuild;
        Rebuild();
    }
    void OnDestroy() { WorldGrid.OnRoomsChanged -= Rebuild; }
    void Update() { mat.color = new Color(0f, 0f, 0f, darkness); }
    void Rebuild()
    {
        var v = new List<Vector3>(); var tr = new List<int>();
        foreach (var c in WorldGrid.IndoorCells())
        {
            int i = v.Count;
            v.Add(new Vector3(c.x - 0.5f, c.y - 0.5f, 0));
            v.Add(new Vector3(c.x + 0.5f, c.y - 0.5f, 0));
            v.Add(new Vector3(c.x + 0.5f, c.y + 0.5f, 0));
            v.Add(new Vector3(c.x - 0.5f, c.y + 0.5f, 0));
            tr.Add(i); tr.Add(i + 2); tr.Add(i + 1);
            tr.Add(i); tr.Add(i + 3); tr.Add(i + 2);
        }
        mesh.Clear();
        if (v.Count > 0) { mesh.SetVertices(v); mesh.SetTriangles(tr, 0); }
    }
}