using System.Collections.Generic;

// Лента уведомлений для панели событий
public static class Notifier
{
    public struct Note { public string text; public int day; }
    public static readonly List<Note> notes = new List<Note>();

    public static void Add(string text)
    {
        notes.Add(new Note { text = text, day = GameTime.Day });
        if (notes.Count > 60) notes.RemoveAt(0);
    }

    public static void Clear() => notes.Clear();
}