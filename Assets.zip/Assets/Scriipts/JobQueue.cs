using System.Collections.Generic;
using UnityEngine;
public enum JobType { Build, Harvest, Haul }
public struct Job
{
public JobType type;
public Vector2Int coord;
public Job(JobType t, Vector2Int c) { type = t; coord = c; }
}
public static class JobQueue
{
static readonly List<Job> jobs = new List<Job>();
public static IReadOnlyList<Job> Jobs => jobs;
public static readonly Dictionary<JobType, int> priority = new Dictionary<JobType, int>
{
{ JobType.Build, 1 }, { JobType.Harvest, 2 }, { JobType.Haul, 3 }
};
public static int Count => jobs.Count;
public static void Add(JobType t, Vector2Int c) => jobs.Add(new Job(t, c));
public static void Requeue(Job j) => jobs.Add(j);
public static void Clear() => jobs.Clear();
public static void CyclePriority(JobType t) { priority[t] = priority[t] % 9 + 1; }
public static bool TryTake(out Job job, bool allowHaul, Vector2Int from, System.Predicate<Job> accept = null)
{
int bestI = -1, bestP = 10;
float bestD = float.MaxValue;
for (int i = 0; i < jobs.Count; i++)
{
if (jobs[i].type == JobType.Haul && !allowHaul) continue;
if (accept != null && !accept(jobs[i])) continue;
int p = priority[jobs[i].type];
float d = (jobs[i].coord - from).sqrMagnitude;
if (p < bestP || (p == bestP && d < bestD)) { bestP = p; bestD = d; bestI = i; }
}
if (bestI < 0) { job = default; return false; }
job = jobs[bestI];
jobs.RemoveAt(bestI);
return true;
}
}