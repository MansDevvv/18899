using UnityEngine;

public enum ResourceType { Wood, Stone, Food }

public class ResourceNode : MonoBehaviour
{
    public ResourceType type = ResourceType.Wood;
    public int amount = 100;
    [HideInInspector] public bool designated;

    public Vector2Int Coord => new Vector2Int(Mathf.RoundToInt(transform.position.x), Mathf.RoundToInt(transform.position.y));

    public void Register()
    {
        WorldGrid.AddResource(this);
        WorldGrid.SetBlocked(Coord);
    }
}