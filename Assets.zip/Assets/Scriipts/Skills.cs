using System.Collections.Generic;
using UnityEngine;

public enum SkillType
{
    Melee, Ranged, Animals, Farming, Construction, Endurance,
    Cooking, Crafting, Research, Medicine, Social, Intellect
}

[System.Serializable]
public class Skill
{
    public int level = 1;
    public float xp = 0f; // 0..100, +1 за действие
}

public static class Skills
{
    public const int MaxLevel = 15;

    // ===== Ближний бой: 1 ур = 0% уворот, 2 урон; до 5 ур +2%/+1, дальше +1.5%/+0.5 =====
    public static float MeleeDodge(int lvl)
    {
        float d = 0f;
        for (int l = 2; l <= lvl; l++) d += l <= 5 ? 2f : 1.5f;
        return d;
    }
    public static float MeleeDamage(int lvl)
    {
        float dmg = 2f;
        for (int l = 2; l <= lvl; l++) dmg += l <= 5 ? 1f : 0.5f;
        return dmg;
    }

    // ===== Дальний бой: 30% попадание, +5% (после 12 ур +3%); ваншот 0%, +0.5% до 10, дальше +0.9% =====
    public static float RangedHit(int lvl)
    {
        float h = 30f;
        for (int l = 2; l <= lvl; l++) h += l <= 12 ? 5f : 3f;
        return Mathf.Min(95f, h);
    }
    public static float RangedOneShot(int lvl)
    {
        float c = 0f;
        for (int l = 2; l <= lvl; l++) c += l <= 10 ? 0.5f : 0.9f;
        return c;
    }

    // ===== Строительство: 1 ур - только дерево 30с; 2 ур - камень 30с, дерево 28с; 15 ур - 5с/6с =====
    public static bool CanBuildStone(int lvl) => lvl >= 2;
    public static float BuildTimeWood(int lvl) => lvl <= 1 ? 30f : Mathf.Lerp(28f, 5f, (lvl - 2) / 13f);
    public static float BuildTimeStone(int lvl) => lvl <= 2 ? 30f : Mathf.Lerp(30f, 6f, (lvl - 2) / 13f);

    // ===== Выносливость: 30с бега на 1 ур -> 600с на 15; восстановление всегда 30с =====
    public static float MaxStamina(int lvl) => Mathf.Lerp(30f, 600f, (lvl - 1) / 14f);
    public const float StaminaRegenTime = 30f;

    // ===== Ум: минимум 5, буст x1 + 0.1 за уровень выше 5 =====
    public static float IntellectXpMult(int lvl) => 1f + Mathf.Max(0, lvl - 5) * 0.1f;
    public static bool IntellectBoosts(SkillType t)
    {
        return t == SkillType.Animals || t == SkillType.Ranged || t == SkillType.Construction ||
               t == SkillType.Cooking || t == SkillType.Medicine || t == SkillType.Social || t == SkillType.Farming;
    }

    // ===== Генерация уровней: обычные чаще низкие, ум 5+ и 8+ редко =====
    public static int RollLevel()
    {
        float[] w = { 14, 13, 12, 11, 10, 9, 7, 5, 3.5f, 2.5f, 1.8f, 1.2f, 0.8f, 0.5f, 0.3f };
        return 1 + Weighted(w);
    }
    public static int RollIntellect()
    {
        float[] w = { 30, 26, 20, 12, 6, 3, 1.6f, 0.9f, 0.5f, 0.3f, 0.2f };
        return 5 + Weighted(w);
    }
    static int Weighted(float[] w)
    {
        float sum = 0;
        foreach (float f in w) sum += f;
        float r = Random.value * sum;
        for (int i = 0; i < w.Length; i++) { r -= w[i]; if (r <= 0) return i; }
        return w.Length - 1;
    }

    public static string Ru(SkillType t)
    {
        switch (t)
        {
            case SkillType.Melee: return "Ближний бой";
            case SkillType.Ranged: return "Дальний бой";
            case SkillType.Animals: return "Животноводство";
            case SkillType.Farming: return "Землеводство";
            case SkillType.Construction: return "Строительство";
            case SkillType.Endurance: return "Выносливость";
            case SkillType.Cooking: return "Готовка";
            case SkillType.Crafting: return "Создание";
            case SkillType.Research: return "Исследование";
            case SkillType.Medicine: return "Медицина";
            case SkillType.Social: return "Общение";
            default: return "Ум";
        }
    }

    // ===== Предыстории по навыку и уровню =====
    public static string StoryFor(SkillType t, int lvl)
    {
        int band = lvl <= 4 ? 0 : lvl <= 9 ? 1 : 2;
        switch (t)
        {
            case SkillType.Melee:
                return band == 2 ? "В прошлом вышибала в таверне - кулаки помнят" :
                       band == 1 ? "Служил в армии, занимался боксом" :
                       "Пару раз дрался в детстве - вот и вся школа";
            case SkillType.Ranged:
                return band == 2 ? "Был сторожем, стрелял ворон с сотни шагов" :
                       band == 1 ? "Охотился на голубей из рогатки и не только" :
                       "Держал в руках пращу один раз в жизни";
            case SkillType.Animals:
                return band == 2 ? "Держал свиноферму, звери его слушались" :
                       band == 1 ? "Вырос в деревне с козой и парой кур" :
                       "С детства боится куриц";
            case SkillType.Farming:
                return band == 2 ? "Кормил всю деревню со своих полей" :
                       band == 1 ? "Была дача с огурцами и теплицей" :
                       "Путает морковку со свёклой";
            case SkillType.Construction:
                return band == 2 ? "Был бригадиром, срубил мельницу за месяц" :
                       band == 1 ? "Помогал соседям строить сарай и баню" :
                       "Один раз держал молоток - и то не той стороной";
            case SkillType.Endurance:
                return band == 2 ? "Работал курьером, марафонцы завидовали" :
                       band == 1 ? "Ходил пешком за 20 км в город за солью" :
                       "Задыхается, поднимаясь по лестнице";
            case SkillType.Cooking:
                return band == 2 ? "Повар с корабля - кормил и из топора" :
                       band == 1 ? "Неплохо варит борщ и печёт хлеб" :
                       "Умудряется пригорать даже воду";
            case SkillType.Crafting:
                return band == 2 ? "Кузнец, делал плуги из обрезков железа" :
                       band == 1 ? "Вырезает деревянные игрушки на продажу" :
                       "Не может склеить картонку";
            case SkillType.Research:
                return band == 2 ? "Помощник алхимика, знает многое" :
                       band == 1 ? "Любит книги про звёзды и травы" :
                       "Читать умеет, но с трудом";
            case SkillType.Medicine:
                return band == 2 ? "Полевой хирург, доставал стрелу ножом" :
                       band == 1 ? "Лечил соседей травами и примочками" :
                       "Падает в обморок от вида крови";
            case SkillType.Social:
                return band == 2 ? "Глашатай, мог заболтать и долги простить" :
                       band == 1 ? "Может поболтать на рынке со всеми" :
                       "Молчалив, как рыба";
            default:
                return band == 2 ? "Светлая голова" : band == 1 ? "Соображает неплохо" : "Прост, как пробка";
        }
    }
}