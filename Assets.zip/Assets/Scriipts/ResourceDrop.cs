using UnityEngine;

public class ResourceDrop : MonoBehaviour
{
    public ResourceType type;
    public int amount;
    public Vector2Int Coord => new Vector2Int(Mathf.RoundToInt(transform.position.x), Mathf.RoundToInt(transform.position.y));
    public bool refund; // если true - при сдаче на склад вернётся в банк
    public bool poison;
}