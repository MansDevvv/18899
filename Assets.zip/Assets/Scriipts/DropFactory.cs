using UnityEngine;

public static class DropFactory
{
    public static GameObject woodPrefab;
    public static GameObject rockPrefab;
    public static GameObject foodPrefab;

    public static ResourceDrop Spawn(Vector2Int c, ResourceType t, int amount,
        bool addHaulJob = true, bool register = true, Vector3 offset = default, bool poison = false)
    {
        if (register)
        {
            var exist = WorldGrid.GetDrop(c);
            if (exist != null && exist.type == t && exist.poison == poison && exist.amount < 100)
            {
                int add = Mathf.Min(amount, 100 - exist.amount);
                exist.amount += add;
                amount -= add;
                if (amount <= 0) return exist;
            }
        }

        GameObject prefab = t == ResourceType.Wood ? woodPrefab : t == ResourceType.Stone ? rockPrefab : foodPrefab;
        if (prefab == null) return null;
        GameObject g = Object.Instantiate(prefab, new Vector3(c.x, c.y, 0) + offset, Quaternion.identity);
        var drop = g.GetComponent<ResourceDrop>();
        drop.type = t;
        drop.amount = Mathf.Min(amount, 100);
        drop.poison = poison;
        if (register) WorldGrid.AddDrop(drop);
        if (addHaulJob) JobQueue.Add(JobType.Haul, c);
        return drop;
    }
}